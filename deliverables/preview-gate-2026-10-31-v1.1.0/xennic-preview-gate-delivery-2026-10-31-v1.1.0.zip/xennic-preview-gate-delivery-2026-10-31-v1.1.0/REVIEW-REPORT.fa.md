# گزارش بازبینی — Xennic Preview Gate

**نسخه:** `1.1.0` — **تاریخ بسته:** ۲۰۲۶-۱۰-۳۱  
**مبنای دقیق کد وبسایت:** `feerozmandi/xennic-website@418de2b5b3a272e79a824ccde5411dc25f1002cc`  
**دامنه:** بستهٔ غیرمحرمانه برای بازبینی دستیار وبسایت؛ بدون اعمال روی gate فعال، VPS یا DNS.

## خلاصهٔ تصمیم

این تحویل یک بازسازی قابل‌دانلود برای بررسی است، نه نسخهٔ آمادهٔ production. تنظیمات Caddy و OAuth2 Proxy candidate هستند؛ scope نهایی GitHub انتخاب/تأیید نشده و Compose OAuth قدیمی فقط مرجع `DO NOT RUN` است. تنها overlay پیشنهادی برای آزمون Payload از یک gate مصنوعی استفاده می‌کند و هیچ احراز هویت واقعی انجام نمی‌دهد. هیچ آزمایش تازه‌ای روی رایانهٔ مالک اجرا نشده است.

اسکن ساختاری/credential-pattern روی فایل‌های بسته موفق شد و Secret واقعی، private key یا توکن شناخته‌شده پیدا نکرد؛ نمونه‌ها فقط placeholder و دادهٔ synthetic دارند. این اسکن تضمین کشف همهٔ Secretها نیست و فایل‌ها همچنان برای بازبینی دستی ارائه می‌شوند.

**اقدام بعدی:** فایل‌های فهرست‌شده در `FILES-FOR-WEBSITE-ASSISTANT.fa.md` را به دستیار وبسایت بدهید و منتظر بازبینی بمانید. پس از آن برنامهٔ آزمون یکپارچهٔ محدود با commit مبنا ارائه خواهد شد؛ اجرا فقط با تأیید صریح مالک.

## طرح Caddy در فایل‌های بسته

`Caddyfile` تنظیم candidate روی `https://preview.xennic.ir` را نشان می‌دهد و `routes.caddy` مسیرها را تعیین می‌کند. فایل `compose.preview.yml` داخل بسته کپی دقیق base Compose از website commit است؛ برای build واقعی در آینده باید از همان فایل داخل checkout سایت استفاده شود تا build context `.` به کد سایت اشاره کند.

- در overlay، Caddy به `gate:4180` برای auth و به `app:3000` برای Payload می‌رسد؛ این نام‌های DNS سرویسی از شبکهٔ اختصاصی همان Compose project هستند. Caddy فقط بعد از پاسخ مجاز از `/oauth2/auth`، upstream برنامه را reverse-proxy می‌کند.
- overlay یک network مختص project با `internal: true` می‌سازد و app، postgres، gate و Caddy را به آن وصل می‌کند؛ نام‌های سرویس `app`, `postgres`, `gate` روی همین شبکه resolve می‌شوند. این network egress را مسدود می‌کند؛ رفتار startup برنامه در چنین شبکه‌ای هنوز اجرا نشده است.
- Compose پایه app را روی `127.0.0.1:${PREVIEW_PORT:-3000}:3000` منتشر می‌کند؛ overlay با `ports: !reset []` آن port را حذف می‌کند. PostgreSQL و gate هیچ host portی ندارند. تنها port منتشرشدهٔ overlay، Caddy روی `127.0.0.1:443:443/tcp` است؛ هیچ bind عمومی تعریف نشده.
- `@api path /api /api/* /graphql /graphql/*` در `routes.caddy` شامل مسیر واقعی Payload GraphQL یعنی `/api/graphql` است. آن مسیر و بقیهٔ `/api/*` از `forward_auth` به `/oauth2/auth` عبور می‌کنند و در نبود gate، 401 می‌گیرند. UI در 401 به `/oauth2/sign_in` هدایت می‌شود.
- `/oauth2/*` فقط به gate می‌رود، نه به Payload. پاسخ callback از gate در `4xx` به پیام عمومی `403` و در `5xx` به پیام عمومی `500` تبدیل می‌شود؛ بدنه، هدرهای داخلی، Set-Cookie و جزئیات provider به کاربر پاس نمی‌شوند و Cache-Control برابر `no-store` است.
- هنگام فراخوانی gate، هدرهای `Authorization` و هدرهای هویت/forwarding ورودی حذف می‌شوند؛ Host/Proto/آدرس مبدأ از Caddy بازسازی می‌شوند.
- هنگام ارسال به Payload، `upstream.caddy` با regex فقط Cookie با نام `__Host-preview_gate` و chunkهای عددی `__Host-preview_gate_N` را از هدر Cookie حذف می‌کند؛ Cookieهای Payload و نامرتبط، Bearer Payload، `Origin` و Fetch Metadata باید حفظ شوند؛ هویت ارسالیِ جعل‌شده حذف می‌شود. این رفتار هدف config/test است و Caddy mock هنوز اجرا نشده.
- `.env.preview.example` فقط placeholderهای آشکار برای متغیرهای Compose دارد؛ فایل واقعی `.env` یا Secret در بسته نیست و نمونه را نباید source/اجرا کرد. `prepare_payload_lab_env.py` تنها پس از مجوز، مقادیر synthetic را خارج از بسته می‌سازد.
- `Caddyfile.lab` از TLS داخلی برای fixture محلی استفاده می‌کند؛ `Caddyfile.payload.lab` نیز TLS داخلی دارد و به نام میزبان preview محدود است. این‌ها TLS عمومی یا آزمون DNS نیستند.

این‌ها **تنظیمات فایل candidate** هستند، نه وضعیت gate فعال یا تنظیم نهایی تأییدشده. تا اجرای `caddy adapt --validate` با نسخهٔ موردنظر، parser اعتبارسنجی نشده است؛ هیچ config زنده‌ای خوانده/نصب/تغییر داده نشده است.

## طرح OAuth2 Proxy و محدودیت مجوز

- `oauth2-proxy.example.toml` یک template عمداً unapproved است: scope برابر `UNAPPROVED_DO_NOT_RUN` و `trusted_proxy_ips` placeholder است. این sentinel مانع فنی startup نیست؛ فایل را اجرا نکنید. parse شدن TOML به‌معنای پذیرفته‌شدن آن توسط OAuth2 Proxy نیست. Candidate دارای `github_users=["feerozmandi"]` (محدودکنندهٔ نام کاربری؛ `email_domains=["*"]` فقط filter ایمیل است)، listen داخلی `0.0.0.0:4180`، upstream ثابت `static://202`، cookie `__Host-preview_gate` با Secure/HttpOnly/Lax، expiry `4h` و refresh `0` است. این expiry با نمونهٔ local قبلی (`1m`) فرق دارد و مقدار ۴ساعته آزموده نشده است. عدم عبور Bearer به gate و تنظیمات دیگر هم فقط طرح بازبینی‌اند.
- `oauth2-proxy.lab.example.toml` به توپولوژی آزمایش قبلی اشاره می‌کند: `user:email read:org` و `172.29.251.2/32`. این مجوز فقط برای OAuth App محلیِ جداگانه‌ای بود که مالک برای آزمون مستقلش تأیید کرده بود؛ scope نهایی App معلوم/تأییدشده نیست و نشانی شبکه نیز به topology قدیمی وابسته است.
- `compose.oauth-lab.reference.yml` ثابت و دارای پورت `127.0.0.1:18443`، subnet `172.29.251.0/28` و project name ثابت است. آن را اجرا نکنید؛ احتمال برخورد با lab مالک وجود دارد.
- `prepare_lab_config.py` اجرا نشده است. در صورت استفادهٔ مجاز در آینده، ورودی Client ID/Secret را مخفی می‌گیرد و فایل خصوصی mode `0600` را خارج از بسته در home می‌سازد؛ هیچ Secretی را در آرشیو یا چت قرار نمی‌دهد. این helper مجوز اجرای آزمون فعلی نیست.

## Overlay و آزمون‌های تحویلی

`compose.payload-lab.override.yml` برای checkout وبسایت دقیقاً روی commit مبناست. project name اختصاصی `xennic-preview-gate-payload-lab` دارد و دستور Runbook نیز `-p` را صریح می‌کند تا volumeهای DB/media از stackهای دیگر جدا بمانند. network اختصاصی `internal: true`، app/Postgres/gate/Caddy را فقط در همان project به هم متصل می‌کند و egress خارجی را محدود می‌کند؛ app/DB host port publish ندارند. این طراحی host را به‌عنوان مرز امنیتی حذف نمی‌کند و رفتار آن در Docker واقعی اجرا نشده است. پورت برنامهٔ Payload در override پاک می‌شود؛ فقط Caddy روی `127.0.0.1:443` منتشر می‌شود. `gate_stub.py` فقط marker مصنوعی را می‌پذیرد؛ OAuth، GitHub، کاربر واقعی و امنیت identity را پیاده‌سازی نمی‌کند. image digestها تأییدنشده‌اند، پس overlay تا بررسی آن‌ها `DO NOT RUN` است. overlay روی هیچ ماشینی اجرا نشده است.

مجموعهٔ آزمون‌ها شامل این موارد است:

1. `test_caddy_mock.py` — آزمون loopback با Caddy و upstream/gate مصنوعی؛ routeها ازجمله `/api/graphql`، حذف Cookie نشست، حفظ Bearer/Cookie اپ، حذف هدر هویتی، پاسخ callback پاک‌شده و چند چیدمان Cookie را می‌سنجد. OAuth/GitHub و Payload server را اجرا نمی‌کند؛ Caddy binary در این محیط موجود نبود و آزمون اجرا نشده است.
2. `test_payload_extraction.mjs` — `extractJWT` واقعی از npm Payload 3.91.0 را با هدرهای مصنوعی می‌خواند؛ برنامهٔ کامل یا DB را اجرا نمی‌کند.
3. `provider-policy-test/` — متدهای سیاست GitHub از منبع ثابت OAuth2 Proxy v7.15.5 استخراج می‌شوند؛ HTTP/session plumbing تستی است. هدف آن تفکیک «پروفایل با موفقیت دریافت شد ولی login خارج از allowlist است» از «درخواست org/team/profile/email به API خطا داد» است؛ callback یا login GitHub واقعی را اجرا نمی‌کند.
4. `test_payload_caddy.mjs` — آزمون یکپارچهٔ پیشنهادی برای Payload واقعی روی DB/media جدا و Caddy محلی، با gate مصنوعی و فقط پس از بازبینی/تأیید؛ هنوز اجرا نشده است.
5. `test_payload_browser.js` — آزمون اختیاری DevTools، فقط برای همان overlay مصنوعی؛ پیش‌فرض اجرا نمی‌شود.
6. `check_caddy_config.py` — `caddy adapt --validate` را برای configها مطالبه می‌کند، اما در محیط تهیهٔ این بسته Caddy نصب نبود و checker اجرا نشده است.

وضعیت اجرای دقیق را در `VALIDATION.fa.md` ببینید. نتیجهٔ آزمون‌های بازسازی‌شده را با نتیجهٔ بستهٔ گمشدهٔ قبلی اشتباه نگیرید.

## نسخه‌ها و digestها

نسخه‌های image در YAML به‌همراه مقادیر digest نوشته شده‌اند، اما دسترسی به registryهای Docker Hub/Quay در محیط بستهٔ تهیه موجود نبود؛ بنابراین digestهای image **به‌صورت مستقل راستی‌آزمایی نشده‌اند** و نباید زنجیرهٔ provenance تلقی شوند. Payload `3.91.0` از npm registry دریافت و `extractJWT` همان tarball آزموده شد؛ SRI/هاش در `VERSIONS-DIGESTS.fa.md` درج شده است. منبع `github.go` از tag `v7.15.5` دریافت و SHA256 بررسی شده است. Node و Postgres در Compose/Dockerfile فقط با tag هستند و digest pin ندارند.

## یافته‌های قبلی که بازتکرار نشده‌اند

نتایج زیر از گزارش‌های آزمایش قبلی مالک حفظ شده‌اند، اما فایل‌های بستهٔ قبلی غایب‌اند و آزمون‌های جاری نیستند:

- ورود مالک با OAuth App محلی پس از درخواست scope محلی `user:email read:org` گزارش شد؛ این scope برای App نهایی تأیید نیست.
- دادهٔ مصنوعی نشان داد Bearer/Cookie Payload حفظ و هدر هویتی جعلی حذف شده است.
- حساب دوم به fixture نرسید و callback `500 missing github user` گزارش شد. **علت معلوم نیست**؛ این مشاهده به‌تنهایی رد allowlist را از شکست provider/API جدا نمی‌کند.
- منقضی‌شدن نشست در حدود ۷۵ ثانیه، logout عادی و اعتبارسنجی مجدد 401 گزارش شد؛ replay نشست قدیمی پس از signout همچنان 200 بود.
- قطع gate فقط بدون نشست معتبر آزموده شد. آزمون outage با نشست معتبر صریحاً خارج از دامنه است و بدون مجوز تازه ممنوع می‌ماند.
- چند مسیر نمونه گزارش شده‌اند، اما پوشش همهٔ routeها ثابت نیست. CI سایت روی commit مبنا گزارش موفق داشت، اما proxy gate واقعی را اجرا نمی‌کند.

هیچ‌یک از موارد بالا روی فایل‌های بازسازی‌شده یا gate زنده در این مرحله دوباره اجرا نشده‌اند.

## تفکیک حساب دوم: قاعدهٔ گزارش

در ارزیابی آتی فقط این دسته‌ها قابل گزارش است:

- **رد سیاست حساب:** پاسخ پروفایل GitHub با موفقیت دریافت و login آن از allowlist خارج است.
- **شکست provider/API:** فراخوانی org/team/profile/email با خطای API/شبکه/پاسخ غیرمنتظره شکست می‌خورد.
- **نامشخص:** دادهٔ کافی برای تعیین مرحله وجود ندارد.

HTTP 403 روی callback یا پیام عمومی به‌تنهایی علت را ثابت نمی‌کند؛ اگر provider API خطا دهد نباید آن را «حساب دوم رد شد» نامید. فقط نتیجهٔ دسته‌بندی‌شده، کد وضعیت/ردهٔ پاسخ و زمان تقریبی درخواست شود؛ **لاگ خام، Cookie، access token، request token/code یا screenshot حاوی این مقادیر درخواست نشود**.

## محدودیت‌های باز و gateهای تصمیم

- scope نهایی OAuth، مالکیت App نهایی، تنظیم callback آن و IP/subnet قابل‌اعتماد هنوز تأیید نشده‌اند.
- digest و provenance همهٔ imageها تأیید نشده؛ Node/Postgres digest pin ندارند.
- Caddyfile، Compose merge، Caddy parser و Go testهای بازسازی‌شده در این محیط اجرا/اعتبارسنجی نشده‌اند. محیط فعلی Docker، Caddy و Go ندارد.
- Payload parser test با npm tarball اجرا شده؛ Payload server/DB و overlay اجرا نشده‌اند.
- گواهی عمومی، DNS، دسترسی شبکه و renewal آزموده نشده‌اند. مشاهدهٔ قبلی `preview.xennic.ir` در تاریخ ۲۰۲۶-۱۰-۳۰ NXDOMAIN بود؛ هیچ DNSی تغییر نکرد.
- replay نشست قدیمی پس از signout، رفتار outage با نشست معتبر، و نتیجهٔ واقعی حساب دوم حل نشده‌اند.
- Open Notebook همچنان paused است و پیش‌شرط preview نیست؛ Hermes و `[RAG-02]` خارج از دامنه‌اند.

**بدون تغییر:** gate فعال، سرویس/VPS، firewall، پورت عمومی، Compose عملیاتی، DNS، Secretها یا volumeهای مالک.
