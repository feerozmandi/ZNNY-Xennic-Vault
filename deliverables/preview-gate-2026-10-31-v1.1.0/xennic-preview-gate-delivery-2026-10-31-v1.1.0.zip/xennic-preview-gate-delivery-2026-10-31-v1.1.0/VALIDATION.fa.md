# وضعیت اعتبارسنجی بستهٔ `1.1.0`

**هیچ آزمون integration یا runtime روی رایانهٔ مالک، gate فعال، VPS یا DNS اجرا نشده و پیش از تحویل نیز اجرا نمی‌شود.** در این بازبسته‌بندی فقط اسکن اطلاعات حساس، ساخت manifest/checksum و آزمون integrity آرشیو انجام می‌شود؛ این‌ها آزمون برنامه نیستند.

## نتیجه‌هایی که از draft قبلی همین نشست حفظ شده‌اند

نتیجه‌های زیر قبل از تغییرات نسخهٔ `1.1.0` به‌دست آمدند؛ آن‌ها را با آزمون نهایی نسخهٔ جاری اشتباه نگیرید:

- Python syntax برای ۸ اسکریپت و Node syntax برای ۳ اسکریپت موفق بود؛ از آن زمان `test_caddy_mock.py` برای `/api/graphql` و `verify_bundle.py` تغییر کرده‌اند، پس syntax نسخهٔ جاری دوباره اجرا نشده است.
- نسخهٔ قبلی overlay و Compose مرجع با YAML parser و custom `!reset` parse شدند؛ در `1.1.0` overlay به شبکهٔ `internal: true` و `.env.preview.example` گسترش یافته و پس از این تغییر parse/Compose merge دوباره اجرا نشده است.
- هر دو OAuth TOML از نظر TOML syntax parse شدند؛ این فایل‌ها تغییری نکرده‌اند.
- `provider-policy-test/generate.py` SHA256 منبع OAuth2 Proxy `v7.15.5` را تطبیق داد و Go source تولید کرد. `go test` اجرا نشد.
- `extractJWT` واقعی Payload `3.91.0` با ۳ Cookie layout مصنوعی و Bearer موفق شد. فایل این آزمون در `1.1.0` تغییر نکرده است؛ Payload server/DB اجرا نشد.

## بررسی تحویل در نسخهٔ جاری

- `verify_bundle.py` روی ساختار نسخهٔ جاری اجرا شد و موفق بود: فایل‌های اجباری/غیرمنتظره، patternهای high-confidence برای private key/GitHub token/OAuth secret، placeholder-only env sample، loopback port و internal-network guard بررسی شدند. اسکن هیچ موردی پیدا نکرد؛ تضمین کشف همهٔ Secretها نیست.
- `MANIFEST.json` و `SHA256SUMS` برای ۳۸ فایل محتوایی ساخته شدند. ZIP نهایی در برابر sidecar SHA256 بررسی شد؛ `unzip -t` موفق بود و پس از استخراج، هر ۳۹ ورودی `SHA256SUMS` و `verify_bundle.py` موفق شدند.
- این اسکن تضمین کشف همهٔ Secretها نیست؛ بازبینی انسانی همچنان لازم است.

## انجام‌نشده / مسدود به‌علت ابزار یا مجوز

- `test_caddy_mock.py` و `check_caddy_config.py`: Caddy binary `2.11.7` موجود نیست.
- `go test ./...`: Go نصب نیست.
- Docker Compose merge و `up`: Docker/Compose موجود نیست و این بسته دستور `up` را پیش از بازبینی/تأیید مجاز نمی‌داند.
- `test_payload_caddy.mjs`: فقط در plan است؛ Payload/Postgres/Caddy stack بالا نیامده است.
- `test_payload_browser.js`: اجرا نشده؛ host mapping یا CA trust تغییر نکرده است.
- `.env.preview.example` فقط placeholder دارد؛ هیچ runtime env، Secret، Cookie یا private file ساخته نشده است.
- OAuth/GitHub واقعی، حساب دوم، outage با نشست معتبر، DNS/TLS عمومی، VPS یا gate فعال: آزموده نشده‌اند.
- image digestها مستقلاً از registry resolve نشده‌اند؛ Node/Postgres tag-only هستند.

## محدودهٔ ادعا

YAML/TOML parsing قبلی جای Compose merge یا Caddy parsing نسخهٔ جاری را نمی‌گیرد؛ Payload parser test، server/API/auth/DB را ثابت نمی‌کند؛ منبع provider pin‌شده تا اجرای Go test نتیجهٔ رفتاری ندارد. callback قبلی حساب دوم همچنان **نامشخص** است. در ارزیابی بعدی فقط دسته‌بندی غیرمحرمانهٔ «پروفایل موفق ولی خارج allowlist»، «provider/API failure» یا «نامشخص» گزارش شود؛ لاگ خام، Cookie، access token یا request code درخواست/ارسال نشود.
