# فایل‌های موردنیاز دستیار وبسایت برای بازبینی

این فهرست مربوط به ZIP نسخهٔ `1.1.0` است؛ بسته شامل ۴۰ فایل است، همگی غیرمحرمانه و بدون runtime Secret. **درخواست از دستیار:** بازبینی فقط ایستا روی commit مبنا؛ هیچ دستوری روی VPS، gate فعال یا حساب OAuth اجرا نشود.

## اولویت ۱ — Compose پایه، overlay و متغیرها

- `compose.preview.yml` — کپی byte-for-byte از base Compose وبسایت در commit مبنا؛ فقط برای بازبینی. در اجرا باید همان فایل از checkout سایت استفاده شود تا build context درست باشد.
- `compose.payload-lab.override.yml` — overlay مستقل بر Compose پایه؛ بررسی `!reset`, internal project network, project isolation, named-volume namespace, حذف publish اپ و loopback-only Caddy.
- `.env.preview.example` — نمونهٔ placeholder-only برای متغیرهای Compose؛ هرگز source یا به Compose ندهید. فایل خصوصی synthetic در آینده فقط با helper ساخته می‌شود.
- `prepare_payload_lab_env.py` — فقط در صورت تأیید، env تصادفی Postgres/Payload را خارج از بسته و mode `0600` می‌سازد؛ در Arena یا روی رایانهٔ مالک اجرا نشده است.

## اولویت ۲ — پیکربندی و ترتیب درخواست

- `Caddyfile` — candidate برای TLS عمومی/ACME؛ بررسی دامنه، issuer، port 443، خاموش‌بودن redirect و HTTP-01، و امکان renewal با محدودیت شبکهٔ فعلی.
- `Caddyfile.payload.lab`, `routes.caddy`, `oauth-gateway.caddy`, `upstream.caddy` — Caddy روی loopback در Compose، دسترسی به `gate:4180` و `app:3000`، حفاظت همهٔ مسیرها ازجمله `/api/graphql`, حفظ Payload Bearer/Cookie، حذف فقط Cookie gate و پاسخ callback عمومی را بررسی کنید.
- `Caddyfile.lab`, `fixture.py` — fixture مستقل قدیمی/مصنوعی، بدون اپلیکیشن واقعی.
- `check_caddy_config.py`, `test_caddy_mock.py` — checker و آزمون Caddy synthetic؛ Caddy binary در محیط بسته نبود و آزمون اجرا نشده است.

## اولویت ۳ — OAuth2 Proxy و provider/API

- `oauth2-proxy.example.toml` — candidate عمداً unapproved؛ scope/IP proxy placeholder هستند.
- `oauth2-proxy.lab.example.toml`, `compose.oauth-lab.reference.yml` — تاریخچه/مرجع قدیمی با `DO NOT RUN`؛ scope محلی قدیمی، port/subnet/project ثابت دارد.
- `provider-policy-test/testdata/github.v7.15.5.go.txt`, `LICENSE.oauth2-proxy` — منبع دقیق upstream و مجوز؛ SHA256 منبع ثبت شده است.
- `provider-policy-test/generate.py`, `provider_extracted.go`, `provider_test.go`, `harness.go`, `requests/requests.go`, `sessions/sessions.go`, `go.mod` — tests و plumbing تستی. Review شود که «پروفایل با موفقیت دریافت شد ولی login خارج از allowlist است» از خطاهای `/user/orgs`, `/user/teams`, `/user`, `/user/emails` جدا باشد. هنوز `go test` اجرا نشده.
- `test_payload_extraction.mjs` — از Payload 3.91.0 واقعی استفاده می‌کند؛ در Arena با tarball همان نسخه و دادهٔ مصنوعی آزموده شد.
- `test_payload_caddy.mjs`, `test_payload_browser.js` — آزمون Payload واقعی/مرورگر پیشنهادی؛ اجرا نشده‌اند. آزمون Node باید فقط با DB جدا و synthetic credentials باشد؛ browser test اختیاری است.

## راهنما، اعتبارسنجی و provenance

- `README.fa.md`, `REVIEW-REPORT.fa.md`, `RUNBOOK.fa.md`, `CHANGELOG.fa.md`, `VERSIONS-DIGESTS.fa.md`, `VALIDATION.fa.md` — راهنما، تنظیمات، محدودیت‌ها، نسخه‌ها و وضعیت آزمون.
- `verify_bundle.py` — بررسی ساختار/placeholderها و checksumهای بسته؛ اسکن کامل Secrets نیست.
- `MANIFEST.json`, `SHA256SUMS` — فهرست/hash فایل‌ها و کنترل یکپارچگی.
- `gate_stub.py` — gate مصنوعی برای overlay Payload؛ OAuth یا مجوز هویت واقعی نیست.

## سؤال‌های باز برای دستیار وبسایت

لطفاً برای هر نکته یکی از «تأیید»، «نیازمند اصلاح» یا «نامعلوم» را ثبت کنید:

1. آیا Caddyfileهای candidate روی Caddy `2.11.7` قابل parse هستند و ترتیب matcherها/`handle_response` دقیقاً همان رفتار موردنظر را دارد؟
2. آیا حذف Cookie با regex در `upstream.caddy` در برابر تمام layoutهای Cookie/چند header قابل قبول است، بدون حذف Payload token یا عبور gate token؟
3. آیا مسیر واقعی `/api/graphql` از matcher `/api/*` با همان `forward_auth` حفاظت می‌شود؟
4. آیا proxy اجازهٔ Bearer برای Payload می‌دهد ولی آن را به OAuth2 Proxy نمی‌فرستد؟ آیا CORS/CSRF و `Origin` با `PREVIEW_ORIGIN` دقیق سازگارند؟
5. آیا تبدیل callback `4xx→403`, `5xx→500` به‌اندازهٔ کافی جزئیات provider را پنهان می‌کند و درعین‌حال دسته‌بندی عملیاتی را برای ادمین ممکن می‌گذارد؟
6. آیا `!reset []` و network `internal: true` برای Compose حداقل v2.24.4 صحیح‌اند و project/volume/network separation در ترکیب فایل‌ها معتبر است؟
7. آیا `Payload 3.91.0` در commit مبنا همچنان رفتار موردانتظار routeهای first-register/login/logout و cookie را دارد؟
8. آیا scope نهایی باید فقط `user:email` باشد، یا دسترسی org/team واقعاً نیاز است؟ **هیچ‌کدام پیش‌فرض یا تأییدشده فرض نشود؛ `read:org` فقط برای OAuth App محلی قدیمی مجاز بود.**
9. برای حساب دوم، چه نشانگرهای غیرمحرمانه‌ای باید سیاست حساب را از provider/API failure جدا کنند؟ لطفاً لاگ خام، Cookie یا توکن درخواست نخواهید.

## کارهایی که بازبین نباید انجام دهد

- هیچ فایل config را روی gate فعال اعمال یا reload نکند.
- OAuth/GitHub callback، account دوم، outage با نشست معتبر، DNS، VPS، عمومی‌کردن port یا Compose عملیاتی را اجرا نکند.
- scope `read:org` را به App نهایی تعمیم ندهد.
- Open Notebook، Hermes یا `[RAG-02]` را آغاز نکند؛ این‌ها خارج از preview و تحت قیود قبلی‌اند.

## فهرست کامل فایل‌های ZIP

`MANIFEST.json` و `SHA256SUMS` نیز در فهرست هستند؛ hash دقیق تک‌تک فایل‌ها در آن‌ها آمده است.

```text
.env.preview.example
CHANGELOG.fa.md
Caddyfile
Caddyfile.lab
Caddyfile.payload.lab
FILES-FOR-WEBSITE-ASSISTANT.fa.md
MANIFEST.json
README.fa.md
REVIEW-REPORT.fa.md
RUNBOOK.fa.md
SHA256SUMS
VALIDATION.fa.md
VERSIONS-DIGESTS.fa.md
check_caddy_config.py
compose.oauth-lab.reference.yml
compose.payload-lab.override.yml
compose.preview.yml
fixture.py
gate_stub.py
oauth-gateway.caddy
oauth2-proxy.example.toml
oauth2-proxy.lab.example.toml
prepare_lab_config.py
prepare_payload_lab_env.py
provider-policy-test/generate.py
provider-policy-test/go.mod
provider-policy-test/harness.go
provider-policy-test/provider_extracted.go
provider-policy-test/provider_test.go
provider-policy-test/requests/requests.go
provider-policy-test/sessions/sessions.go
provider-policy-test/testdata/LICENSE.oauth2-proxy
provider-policy-test/testdata/github.v7.15.5.go.txt
routes.caddy
test_caddy_mock.py
test_payload_browser.js
test_payload_caddy.mjs
test_payload_extraction.mjs
upstream.caddy
verify_bundle.py
```
