# Runbook مرحله‌ای — فقط پس از بازبینی و مجوز

## وضعیت توقف فعلی

**فعلاً هیچ مرحلهٔ اجرایی روی رایانهٔ مالک مجاز نیست.** این Runbook برای بازبینی است؛ ابتدا بسته به دستیار وبسایت داده شود. پس از دریافت نظر دستیار، برنامهٔ آزمون یکپارچهٔ محدود با مبنای commit در گزارش ارائه می‌شود. اجرای آن فقط با تأیید صریح مالک مجاز است.

هیچ دستور این سند را روی VPS، gate فعال، DNS یا Compose عملیاتی اجرا نکنید. فایل `compose.oauth-lab.reference.yml` را اجرا نکنید. آزمون outage با نشست معتبر در هیچ مرحله‌ای گنجانده نشده است. فرمان‌ها برای Bash/POSIX نوشته شده‌اند؛ در Windows معادل‌سازی/WSL را بدون بازبینی مجزا اجرا نکنید.

## مرحلهٔ صفر — کنترل بسته، بدون اجرای سرویس

پس از دریافت ZIP و استخراج آن، در ریشهٔ بسته:

```sh
sha256sum -c SHA256SUMS
python3 verify_bundle.py
```

Checksum ZIP را جداگانه با فایل sidecar مقایسه کنید. سپس فایل‌های `README.fa.md`، `REVIEW-REPORT.fa.md`، `CHANGELOG.fa.md` و `FILES-FOR-WEBSITE-ASSISTANT.fa.md` را بازبینی کنید. این مرحله فقط خواندنی است.

## مرحلهٔ یک — پیش‌نیاز/هویت کد (پس از بازبینی)

در checkout مستقل وبسایت، فقط commit مبنا را تأیید کنید؛ روی `dev`، `main` یا شاخهٔ عملیاتی جابه‌جا نشوید و هیچ فایل سایت را تغییر ندهید:

```sh
git -C /path/to/xennic-website rev-parse HEAD
```

خروجی مورد انتظار: `418de2b5b3a272e79a824ccde5411dc25f1002cc`. اگر checkout متفاوت است، توقف کنید. برای آزمون provider به Go 1.23+، برای parser به Node 22 و Payload 3.91.0، و برای Caddy mock/parser به Caddy 2.11.7 دقیق نیاز است. برای Compose overlay نسخهٔ Docker Compose v2.24.4+ لازم است. اگر هر نسخه یا فایل checkout متفاوت است، آزمون را اجرا نکنید.

## مرحلهٔ دو — آزمون‌های بی‌سرویس (پس از بازبینی)

این دستورات هیچ Docker service یا پورت عمومی را راه‌اندازی نمی‌کنند؛ با این حال روی دستگاه مالک، آن‌ها را پیش از بازبینی اجرا نکنید.

```sh
python3 - <<'PY'
from pathlib import Path
for name in ['check_caddy_config.py','test_caddy_mock.py','fixture.py','gate_stub.py','prepare_lab_config.py','prepare_payload_lab_env.py','provider-policy-test/generate.py']:
    compile(Path(name).read_text(), name, 'exec')
print('PASS Python syntax (in-memory; no __pycache__ written)')
PY
node --check test_payload_extraction.mjs
node --check test_payload_caddy.mjs
node --check test_payload_browser.js
python3 provider-policy-test/generate.py
(cd provider-policy-test && go test ./...)
```

`prepare_lab_config.py` و `prepare_payload_lab_env.py` **جزو این مرحله نیستند**؛ این دو فایل خصوصی خارج از بسته می‌سازند و فقط در مرحلهٔ مربوط، پس از تأیید، اجرا شوند. `generate.py` منبع ثابت را با SHA256 می‌سنجد و فایل Go تولیدشده را به‌روز می‌کند؛ پس از آن `python3 verify_bundle.py` را دوباره اجرا کنید تا تغییر ناخواستهٔ بسته دیده شود.

آزمون استخراج JWT با Payload نصب‌شده در checkout دقیق:

```sh
printf '%s' '[{"cookie":"payload-token=synthetic; other=keep"},{"cookie":"; payload-token=synthetic; ; other=keep"}]' \
  | PAYLOAD_PACKAGE_DIR=/path/to/xennic-website/node_modules/payload node test_payload_extraction.mjs
```

فقط دادهٔ مصنوعی استفاده می‌شود. اگر `node_modules/payload/package.json` نسخهٔ `3.91.0` نیست یا import شکست خورد، توقف کنید؛ پکیج دیگری را نصب/به‌روزرسانی نکنید تا برنامه اصلاح شود.

## مرحلهٔ سه — آزمون Caddy با mock loopback (فقط پس از مجوز صریح)

این آزمون Caddy 2.11.7 را روی پورت تصادفی `127.0.0.1` اجرا می‌کند و دو mock محلی دارد؛ OAuth2 Proxy، DNS، VPS و Payload واقعی ندارد. قبل از اجرا مطمئن شوید Caddy binary همان نسخه است و برای اجرای کوتاه‌مدت مجوز دارید:

```sh
CADDY_BIN=/path/to/caddy-2.11.7 python3 test_caddy_mock.py
CADDY_BIN=/path/to/caddy-2.11.7 python3 check_caddy_config.py
```

فرایند mock خودکار متوقف می‌شود. اگر Caddy خروج کرد، port درگیر بود یا parser خطا داد، آزمون را متوقف کنید؛ پورت/تنظیم live را تغییر ندهید. فقط ردهٔ نتیجه و نام آزمون را گزارش کنید، نه logهای خام.

## مرحلهٔ چهار — Payload واقعی با gate مصنوعی (فقط پس از بازبینی دستیار وبسایت و تأیید مالک)

این مرحله برنامهٔ پیشنهادی است، نه مجوز کنونی. فقط روی checkout مستقل وبسایت با commit دقیق اجرا شود؛ هیچ OAuth، GitHub واقعی، DNS، میزبان عمومی، tunnel یا service فعال استفاده نمی‌شود. `compose.preview.yml` داخل بسته برای بازبینی است؛ دستور build باید از `compose.preview.yml` داخل checkout استفاده کند تا context `.` به کد سایت دقیق برسد. اگر هر پیش‌شرط نامعلوم است، متوقف شوید.

۱. در ریشهٔ checkout، موجودبودن `compose.preview.yml` و آزادبودن `127.0.0.1:443` را بررسی کنید. هیچ سرویسی را برای آزادکردن پورت متوقف نکنید. اگر پورت درگیر است، **توقف**؛ این بسته برای تغییر پورت بازبینی نشده است.

۲. مطمئن شوید پروژه‌ای با نام `xennic-preview-gate-payload-lab`، یا volumeهای آن، از قبل وجود ندارد. در این بررسی فقط فهرست را ببینید؛ data volume را باز نکنید:

```sh
docker compose ls --all
docker volume ls --filter label=com.docker.compose.project=xennic-preview-gate-payload-lab
```

اگر پروژه یا volume از قبل وجود دارد، آن را reuse یا پاک نکنید. فقط پس از بررسی مالک، project name تازهٔ یکتا و برنامهٔ جداگانه لازم است.

۳. فقط پس از مجوز، فایل env مصنوعی بسازید:

```sh
python3 /path/to/bundle/prepare_payload_lab_env.py
```

این دستور فایل `~/.config/xennic-preview-gate-delivery/payload-lab.env` را با mode `0600` می‌سازد؛ مقادیر random هستند و روی صفحه چاپ نمی‌شوند. آن را باز/ارسال/commit نکنید. فایل `.env.preview.example` داخل بسته فقط راهنماست؛ آن را source یا به Compose ندهید. فایل خصوصی فقط برای Postgres و Payload disposable است، نه OAuth.

۴. در ریشهٔ checkout، `BUNDLE` را به مسیر کامل پوشهٔ استخراج‌شده تنظیم کنید، سپس **فقط config را اعتبارسنجی کنید**. `LAB_DIR` باید در environment باشد؛ `--quiet` را حذف نکنید تا مقادیر env چاپ نشوند:

```sh
BUNDLE=/absolute/path/to/xennic-preview-gate-delivery-2026-10-31-v1.1.0
ENV_FILE="$HOME/.config/xennic-preview-gate-delivery/payload-lab.env"
LAB_DIR="$BUNDLE" docker compose --env-file "$ENV_FILE" \
  -p xennic-preview-gate-payload-lab \
  -f compose.preview.yml -f "$BUNDLE/compose.payload-lab.override.yml" config --quiet
```

اگر Compose کمتر از v2.24.4 است، `!reset` را نشناخت، یا `config --quiet` خطا داد، **توقف**. `docker compose config` را بدون `--quiet` اجرا نکنید؛ ممکن است envهای محرمانه را چاپ کند.

۵. **شرط توقف الزامی پیش از `up`:** در این نسخه digestهای Caddy/Python فقط مقادیر ثبت‌شده‌اند و registry verification ندارند؛ Node/Postgres پایه نیز digest ندارند. تا زمانی که دستیار وبسایت/مالک imageها را از registry معتبر independently بررسی و نسخه/ digest صحیح را در patch بازبینی‌شده تثبیت نکرده‌اند، این مرحله را اجرا نکنید. پس از آن هم تأیید صریح مالک لازم است. هیچ tag یا digestی را خودسرانه در این بسته تغییر ندهید.

۶. پس از تحقق شرط بالا و تأیید مجدد، stack مصنوعی را بالا بیاورید:

```sh
LAB_DIR="$BUNDLE" docker compose --env-file "$ENV_FILE" \
  -p xennic-preview-gate-payload-lab \
  -f compose.preview.yml -f "$BUNDLE/compose.payload-lab.override.yml" up -d --build
```

هیچ host portی جز `127.0.0.1:443` منتشر نمی‌شود؛ app و Postgres port publish ندارند. هر چهار سرویس روی network اختصاصی project با `internal: true` هستند و network خروجی به اینترنت را محدود می‌کند؛ این موضوع egress و health/startup را نیازمند بررسی می‌گذارد. gate stub فقط در همان network داخلی است. Caddy از CA محلی خودش استفاده می‌کند. اگر خروجی `ps` پورت غیر-loopback/غیرمنتظره نشان داد، آزمون را متوقف کنید و چیزی را restart یا تغییر ندهید.

۷. فهرست port mapping را بررسی کنید. خروجی باید فقط `127.0.0.1:443->443/tcp` برای Caddy داشته باشد؛ اگر هر port دیگری منتشر شده یا bind به `0.0.0.0` است، فوراً توقف کنید:

```sh
LAB_DIR="$BUNDLE" docker compose --env-file "$ENV_FILE" -p xennic-preview-gate-payload-lab \
  -f compose.preview.yml -f "$BUNDLE/compose.payload-lab.override.yml" ps
```

۸. گواهی عمومی CA را فقط برای کلاینت تست به‌کار ببرید؛ هیچ private key را کپی نکنید. CA محلی Caddy داخل volume در `caddy:/data/caddy/pki/authorities/local/root.crt` است. پس از بالا آمدن Caddy می‌توان گواهی عمومی را به یک مسیر موقت بیرون از Git کپی کرد:

```sh
CID=$(LAB_DIR="$BUNDLE" docker compose --env-file "$ENV_FILE" -p xennic-preview-gate-payload-lab \
  -f compose.preview.yml -f "$BUNDLE/compose.payload-lab.override.yml" ps -q caddy)
test -n "$CID" || { echo 'Caddy container not found; stop.'; exit 1; }
docker cp "$CID:/data/caddy/pki/authorities/local/root.crt" "$HOME/.config/xennic-preview-gate-delivery/lab-root.crt"
```

فقط `root.crt` عمومی را کپی کنید، نه `root.key`. این آزمون Node با resolver داخلی خود فقط `127.0.0.1` را هدف می‌گیرد؛ نیازی به تغییر `/etc/hosts` یا DNS نیست. سپس:

```sh
LAB_CA_FILE="$HOME/.config/xennic-preview-gate-delivery/lab-root.crt" \
  node "$BUNDLE/test_payload_caddy.mjs"
```

آزمون فقط یک Staff مصنوعی در DB جدید می‌سازد؛ token/password چاپ نمی‌کند. اگر DB جدید نبود، درخواست ثبت اول شکست خورد، TLS اعتبارسنجی نشد یا status غیرمنتظره بود، آزمون را متوقف کنید. برای مرورگر، `test_payload_browser.js` اختیاری است و به host mapping و trust محلی نیاز دارد؛ در برنامهٔ محدود فعلی از آن صرف‌نظر کنید و CA را به trust store سیستم/مرورگر نصب نکنید.

## مرحلهٔ پنج — توقف و بازگشت

پس از آزمون، در همان checkout و با همان `-p`، `--env-file` و دو Compose file:

```sh
LAB_DIR="$BUNDLE" docker compose --env-file "$ENV_FILE" \
  -p xennic-preview-gate-payload-lab \
  -f compose.preview.yml -f "$BUNDLE/compose.payload-lab.override.yml" down
```

`down` بدون `-v` فقط containerها و network همین project یکتا را جمع می‌کند؛ named volumeها باقی می‌مانند تا هیچ داده‌ای بی‌اجازه حذف نشود. این Runbook هرگز `docker compose down -v`، `docker volume rm`، restart سرویس موجود، حذف volume، یا stop کردن سرویس دیگری را مجاز نمی‌کند. گواهی `lab-root.crt` یک فایل عمومی آزمایشی است و در صورت پایان نیاز می‌توان آن را از مسیر خصوصی آزمایش پاک کرد؛ این کار volume را لمس نمی‌کند.

در صورت توقف زودهنگام: ابتدا دستور `down` بالا را فقط برای همین project یکتا اجرا کنید؛ اگر نام project/containerها تطبیق ندارد، هیچ cleanup نکنید و از مالک سؤال کنید. سپس نتیجه را فقط در قالب «نام مرحله + PASS/FAIL/STOP + status code/دستهٔ خطا + زمان تقریبی» گزارش دهید. لاگ خام، Cookie، token، OAuth `code`، password و env file ارسال نشود.

## خارج از Runbook

- `compose.oauth-lab.reference.yml` و هر فایل OAuth محلی: اجرا نکنید؛ پورت/شبکه/project name قدیمی و scope محلی دارد.
- اتصال حساب واقعی دوم یا تشخیص callback از روی پیام عمومی: بدون plan و مجوز تازه انجام نشود.
- outage با نشست معتبر: خارج از دامنه و ممنوع بدون مجوز تازه.
- VPS، DNS، firewall، پورت عمومی، Compose عملیاتی، Hermes، Open Notebook، `[RAG-02]` و تنظیمات دیگر: این بسته هیچ‌کدام را تغییر نمی‌دهد.
