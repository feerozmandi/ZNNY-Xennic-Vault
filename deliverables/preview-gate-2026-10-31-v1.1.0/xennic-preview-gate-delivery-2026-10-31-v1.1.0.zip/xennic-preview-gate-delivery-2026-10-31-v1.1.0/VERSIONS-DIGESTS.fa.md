# نسخه‌ها، digestها و منشأ

**مبنای برنامهٔ وبسایت:** `feerozmandi/xennic-website@418de2b5b3a272e79a824ccde5411dc25f1002cc` (PR #10 ادغام‌شده). این commit را با نسخهٔ جاری branch اشتباه نگیرید.

کپی `compose.preview.yml` داخل بسته از فایل همان مسیر در commit بالا گرفته شده است؛ SHA256 آن `e00963aed6cd1b6d87a27af55b71f662304097a338e519d7f286dcbc3c40918c` است و در `MANIFEST.json` نیز ثبت می‌شود. برای اجرای آینده، فایلِ checkout سایت و `Dockerfile.preview` همان commit لازم است؛ کپی داخل ZIP فقط مرجع بازبینی است.

## وابستگی‌ها و image referenceهای پیکربندی‌شده

| مؤلفه | نسخه/مرجع ثبت‌شده | digest / شناسنامه | وضعیت راستی‌آزمایی در این بسته |
|---|---|---|---|
| Payload CMS | `3.91.0` | npm tarball SHA256 `3d93c82261fde3d01877c036b64f5fc8f342a6c97192402725d782cb7c50eec3`; SRI `sha512-EF+PXc8iSuo561f82SnAY5YB8Ix6LDN4Xe4ndef0iLDNPkdEykq1vc1mgo82/HsZ4ljSv9u/wP6iP5hyIpM+wA==`; npm shasum `91fddbf74ab60484d9298a83ffab67e4ceab751c` | tarball از `registry.npmjs.org` دریافت؛ package version بررسی؛ `extractJWT` واقعی با mock data آزموده شد. این hash، کل dependency tree سایت را پین نمی‌کند. |
| Node base image | `node:22.22.3-bookworm-slim` | digest ثبت نشده | tag در Dockerfile commit مبنا خوانده شد؛ registry digest/provenance مستقل تأیید نشده است. |
| PostgreSQL | `postgres:16.14-bookworm` | digest ثبت نشده | tag در Compose commit مبنا خوانده شد؛ registry digest/provenance مستقل تأیید نشده است. |
| Caddy | `caddy:2.11.7@sha256:36c24ad91a7ff7bc4c87fe22bfa8df3c4b18da0773d73fc12ee2c52b98c0bb7e` | digest نوشته‌شده در YAML | مقدار از تنظیم بازسازی‌شده ثبت شده، اما manifest/registry OCI در محیط قابل‌دسترسی نبود؛ **تأییدنشده**. Caddy binary موجود نبود و config/test parse اجرا نشد. |
| OAuth2 Proxy | `quay.io/oauth2-proxy/oauth2-proxy:v7.15.5@sha256:8498b0d0ef0a7b29686414000a08aee467f02d0299c9ed1e006a8f33fc017916` | digest نوشته‌شده در Compose مرجع | مقدار image digest **تأییدنشده**؛ registry در دسترس نبود. Source code tag `v7.15.5` به‌طور جداگانه hash شده، اما این امر image digest را اثبات نمی‌کند. |
| Python fixture/stub | `python:3.12.8-alpine@sha256:ba13ef990f6e5d13014e9e8d04c02a8fdb0fe53d6dccf6e19147f316e6cc3a84` | digest نوشته‌شده در Compose | image digest **تأییدنشده**؛ fixture کد محلی ساده است و container اجرا نشده است. |
| Docker Compose syntax | حداقل `v2.24.4` پیشنهادی | `!reset []` در override | نسخه روی میزبان مالک نصب/بررسی نشده؛ Compose وجود ندارد. حداقل را پیش از اجرا دوباره بررسی کنید. |
| Go policy tests | `go 1.23` در `go.mod` | source methods pin شده با SHA256 | Go در محیط نصب نبود؛ compile/test اجرا نشده است. |
| محیط بازسازی | Python `3.11.2`, Node `v22.22.3` | runtime محلی Arena | Docker، Caddy و Go در PATH نبودند. |

### منبع OAuth2 Proxy

- فایل: `providers/github.go` از tag `v7.15.5`
- tag object: `6e4bd00eea928c0268871954000f1f4fa8c91d30`
- SHA256 فایل منبع: `03aee25d95c40af66cdbe932eca288f594621c2ee40696ce88b03be45cfa075e`
- کپی در بسته: `provider-policy-test/testdata/github.v7.15.5.go.txt`
- `generate.py` پیش از ساخت فایل Go همین SHA256 را بررسی می‌کند.
- تصویر container/باینری OAuth2 Proxy از روی این فایل منبع ساخته نشده و hash منبع، digest آن را تأیید نمی‌کند.

## مرجع‌های عمومی

- Website commit: `https://github.com/feerozmandi/xennic-website/commit/418de2b5b3a272e79a824ccde5411dc25f1002cc`
- Website PR #10: `https://github.com/feerozmandi/xennic-website/pull/10`
- OAuth2 Proxy GitHub provider v7.15.5: `https://github.com/oauth2-proxy/oauth2-proxy/blob/v7.15.5/providers/github.go`
- OAuth2 Proxy release v7.15.5: `https://github.com/oauth2-proxy/oauth2-proxy/releases/tag/v7.15.5`
- Caddy reverse_proxy header directives: `https://caddyserver.com/docs/caddyfile/directives/reverse_proxy`
- Docker Compose merge tags: `https://docs.docker.com/reference/compose-file/merge/`
- Payload npm package: `https://registry.npmjs.org/payload/-/payload-3.91.0.tgz`

## تفسیر digest

`sha256:` در reference یک container image digest را نشان می‌دهد، ولی در این تحویل فقط مقدار نوشته‌شده را بازگو می‌کند. برای اثبات، دستیار وبسایت/مالک باید manifest همان tag/platform را از registry معتبر independently resolve و مقدار digest را مقایسه کند. تا آن زمان آن digest را pin معتبر یا provenance تأییدشده قلمداد نکنید. هیچ image pull یا container run در Arena انجام نشد.
