// Isolated integration test for REAL Payload 3.91.0 behind Caddy + synthetic gate.
// Requires website commit 418de2b5, a fresh disposable DB/media project, the
// reviewed overlay and a public local Caddy CA. It maps only this Node process
// to 127.0.0.1. Never targets VPS/public DNS and prints no credentials/tokens.
import assert from 'node:assert/strict'
import { randomBytes, randomUUID } from 'node:crypto'
import { readFileSync } from 'node:fs'
import https from 'node:https'

const origin = 'https://preview.xennic.ir'
const hostname = 'preview.xennic.ir'
const caFile = process.env.LAB_CA_FILE
assert(caFile, 'Set LAB_CA_FILE to the public root certificate from the isolated Caddy lab')
const ca = readFileSync(caFile)
const gateCookie = '__Host-preview_gate=synthetic-owner'

function request(path, {method='GET', body, headers={}, withGate=true}={}) {
  return new Promise((resolve, reject) => {
    const outgoing = {Host:hostname, ...headers}
    if (withGate) outgoing.Cookie = [gateCookie, outgoing.Cookie].filter(Boolean).join('; ')
    if (body !== undefined) outgoing['Content-Length'] = Buffer.byteLength(body)
    const req = https.request({hostname, servername:hostname, port:443, path, method, headers:outgoing,
      ca, rejectUnauthorized:true,
      lookup(_host, options, cb) {
        if (options?.all) cb(null, [{address:'127.0.0.1', family:4}])
        else cb(null, '127.0.0.1', 4)
      },
    }, res => {
      const chunks=[]
      res.on('data', c => chunks.push(c))
      res.on('end', () => resolve({status:res.statusCode, headers:res.headers, body:Buffer.concat(chunks).toString('utf8')}))
    })
    req.on('error', reject)
    if (body !== undefined) req.write(body)
    req.end()
  })
}
function check(ok, label) { assert(ok, label); console.log('PASS', label) }

const json = {'Content-Type':'application/json', Origin:origin}
const email = `lab-${randomUUID()}@example.invalid`
const password = randomBytes(32).toString('base64url')
let token = ''

try {
  let r = await request('/api/staff/me', {withGate:false})
  check(r.status === 401, 'API denied without synthetic gate marker')
  r = await request('/admin', {withGate:false})
  check(r.status === 302, 'admin redirects without synthetic gate marker')

  r = await request('/api/staff/first-register', {method:'POST', headers:json,
    body:JSON.stringify({name:'Synthetic Preview Test', email, password})})
  check(r.status === 200, 'fresh disposable DB creates synthetic first Staff')

  r = await request('/api/staff/login', {method:'POST',
    headers:{'Content-Type':'application/json', Origin:'https://untrusted.example.invalid'},
    body:JSON.stringify({email,password})})
  check(r.status === 403 && !r.headers['set-cookie'], 'untrusted-Origin login rejected without issuing cookie')

  r = await request('/api/staff/login', {method:'POST', headers:json, body:JSON.stringify({email,password})})
  check(r.status === 200, 'synthetic Staff login succeeds through Caddy')
  const loginBody = JSON.parse(r.body)
  token = typeof loginBody.token === 'string' ? loginBody.token : ''
  check(Boolean(token), 'Payload returned synthetic Bearer token')
  const setCookies = Array.isArray(r.headers['set-cookie']) ? r.headers['set-cookie'] : []
  const setCookie = setCookies.find(v => /^payload-token=/.test(v))
  check(Boolean(setCookie), 'Payload cookie passed through proxy')
  check(/(?:^|;)\s*HttpOnly(?:=true)?(?:;|$)/i.test(setCookie), 'Payload cookie HttpOnly')
  check(/(?:^|;)\s*SameSite=Lax(?:;|$)/i.test(setCookie), 'Payload cookie SameSite=Lax')
  check(/(?:^|;)\s*Secure(?:=true)?(?:;|$)/i.test(setCookie), 'Payload cookie Secure')
  check(/(?:^|;)\s*Path=\/(?:;|$)/i.test(setCookie), 'Payload cookie Path=/')
  check(!/(?:^|;)\s*Domain=/i.test(setCookie), 'Payload cookie host-only')
  const payloadCookie = setCookie.split(';',1)[0]

  r = await request('/api/staff/me', {headers:{Cookie:payloadCookie, Origin:origin}})
  const cookieMe = r.status === 200 ? JSON.parse(r.body) : {}
  check(r.status === 200 && Boolean(cookieMe.user?.email), 'Payload Cookie auth works through Caddy')

  r = await request('/api/staff/me', {headers:{Cookie:payloadCookie, Origin:'https://untrusted.example.invalid'}})
  const untrustedMe = r.status === 200 ? JSON.parse(r.body) : {}
  check(r.status === 200 && !untrustedMe.user, 'Payload rejects forwarded untrusted Origin for Cookie auth')

  r = await request('/api/staff/logout', {method:'POST', headers:{Cookie:payloadCookie, Origin:origin}})
  check(r.status === 200, 'Payload logout succeeds through Caddy')
  const expired = Array.isArray(r.headers['set-cookie']) ? r.headers['set-cookie'].find(v => /^payload-token=/.test(v)) : r.headers['set-cookie']
  check(Boolean(expired) && /(?:Max-Age=0|Expires=)/i.test(expired), 'Payload logout expires its cookie')

  // No Payload Cookie is sent here. The synthetic gate marker is still supplied
  // to Caddy and the Caddy upstream filter removes it before the real app.
  r = await request('/api/staff/me', {headers:{Authorization:`Bearer ${token}`, Origin:origin}})
  const bearerMe = r.status === 200 ? JSON.parse(r.body) : {}
  check(r.status === 200 && Boolean(bearerMe.user?.email), 'Payload Bearer works with Payload Cookie omitted')
  console.log('LIMITATION: synthetic gate only; no OAuth2 Proxy or GitHub account was tested.')
} finally {
  token = ''
}
