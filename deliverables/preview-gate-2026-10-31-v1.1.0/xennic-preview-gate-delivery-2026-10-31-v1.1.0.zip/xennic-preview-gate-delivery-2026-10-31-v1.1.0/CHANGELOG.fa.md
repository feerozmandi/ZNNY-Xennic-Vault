# تفاوت با بستهٔ قبلی

## نسخهٔ جاری: `1.1.0` (بازبسته‌بندی پس از توقف دریافت)

این نسخه جایگزین آرشیو قبلی همین نشست است و مواردی را که برای بازبینی/تحویل لازم بود روشن‌تر و کامل‌تر می‌کند: Compose پایهٔ دقیق از commit، فایل env فقط-placeholder، network داخلی محدود، آزمون صریح `/api/graphql` و نسخه‌گذاری تازه. نام آرشیو جاری `xennic-preview-gate-delivery-2026-10-31-v1.1.0.zip` است؛ آرشیو با نام بدون نسخه superseded است.

## وضعیت فایل قبلی

پوشهٔ ارجاع‌شدهٔ قبلی در این نشست فقط `فهرست-فایل‌ها.md` را داشت؛ README، config، گزارش و ZIP قبلی پیدا نشدند. checksum تاریخی ZIP گزارش‌شده `c889d7b1d7c508bf48c0dc70f601e4506cdeeb622e640133a96e270268357966` است، اما خود آن ZIP برای استخراج/مقایسه در دسترس نبود. بنابراین **diff خط‌به‌خط یا ادعای برابری/بهبود کامل قابل اثبات نیست**. این بسته از نو ساخته شده و نباید جایگزین خودکار نسخهٔ پیشین تلقی شود.

## تفاوت‌های قابل مشاهده در بازسازی جاری

- بستهٔ جاری با baseline دقیق وبسایت `418de2b5b3a272e79a824ccde5411dc25f1002cc` مستند شده است؛ Payload `3.91.0`, Node `22.22.3-bookworm-slim` و PostgreSQL `16.14-bookworm` از همان checkout استخراج شده‌اند.
- Caddy configهای جداگانه برای candidate عمومی، fixture محلی و آزمون Payload واقعی اضافه شده‌اند. پاسخ callback در candidate عمومی به پیام عمومی/no-store تبدیل می‌شود تا بدنه و headerهای provider به کاربر نرسند.
- policy حذف Cookie نشست OAuth به‌طور محدود در `upstream.caddy` تعریف شده است؛ هدف این است که Cookieهای Payload و Bearer آن باقی بمانند. `test_caddy_mock.py` برای بررسی چیدمان‌های Cookie و چند هدر نوشته شده است، اما روی Caddy بازسازی‌شده هنوز اجرا نشده.
- فایل OAuth نهایی عمداً با scope نامعتبر/placeholder غیرقابل اجرا شده است؛ scope `user:email read:org` فقط در نمونهٔ محلی قدیمی باقی مانده و صریحاً برای App نهایی تأییدنشده علامت خورده است.
- Compose قدیمی OAuth اکنون `DO NOT RUN` است و برخورد احتمالی project/port/subnet ثابت را اعلام می‌کند.
- Compose پایهٔ `compose.preview.yml` دقیقاً از baseline داخل بسته آمده و یک `.env.preview.example` با placeholder صرف اضافه شده است؛ هیچ env واقعی وارد نشده.
- یک Payload overlay مجزا با gate مصنوعی، project isolation، network اختصاصی `internal: true`، app port پاک‌شده و Caddy loopback/internal TLS اضافه شده است؛ اجرای آن مجاز/انجام‌شده نیست.
- مسیر واقعی Payload GraphQL یعنی `/api/graphql` صریحاً به آزمون mock افزوده شده و با matcher `/api/*` باید `forward_auth` بگیرد.
- تست سیاست provider از `github.go` واقعی v7.15.5 با SHA256 پین‌شده تولید می‌شود تا «کاربر خارج allowlist» با خطای API تفکیک شود؛ plumbing تستی است و `go test` هنوز اجرا نشده.
- تست `extractJWT` Payload 3.91.0 واقعی از npm tarball اجرا شد؛ نتیجهٔ آن در `VALIDATION.fa.md` ثبت می‌شود. این تست جایگزین اجرای Payload server/DB نیست.
- Runbook، فهرست فایل‌های دستیار وبسایت، ثبت نسخه/digest، وضعیت آزمون، checksum و اسکن عدم‌وجود Secret به بسته افزوده شده‌اند.

## نتایج قبلی که تغییر محسوب نمی‌شوند

نتیجه‌های آزمایش قبلی مالک (ورود محلی، Bearer/Cookie مصنوعی، expiry/logout، replay نشست، callback حساب دوم و چند مسیر) شواهد تاریخی‌اند و با بازسازی جاری تکرار نشده‌اند. جزئیات/محدودیت آن‌ها در گزارش آمده است؛ به‌ویژه callback `500 missing github user` علت واقعی حساب دوم را ثابت نمی‌کند و replay نشست پس از signout حل نشده است.
