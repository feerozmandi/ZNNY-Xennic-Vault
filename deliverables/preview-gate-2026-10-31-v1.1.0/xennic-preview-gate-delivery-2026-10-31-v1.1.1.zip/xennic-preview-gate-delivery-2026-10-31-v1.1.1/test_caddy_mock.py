#!/usr/bin/env python3
"""Caddy 2.11.7 routing test with synthetic gate/upstream, loopback only.
No OAuth, GitHub, Docker, Payload server, or external network is used.
"""
import http.client
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

BASE = Path(__file__).resolve().parent
CADDY = os.environ.get('CADDY_BIN', 'caddy')

class State:
    valid = True
    app_requests = []
    auth_cookie_headers = []
    auth_authorization = []
    auth_decisions = []

class Gate(BaseHTTPRequestHandler):
    def log_message(self, *_): pass
    def do_GET(self):
        State.auth_cookie_headers = self.headers.get_all('Cookie', [])
        State.auth_authorization = self.headers.get_all('Authorization', [])
        if self.path.startswith('/oauth2/auth'):
            ok = State.valid and any(
                part.strip() == '__Host-preview_gate=owner'
                for value in State.auth_cookie_headers for part in value.split(';')
            )
            State.auth_decisions.append(ok)
            self.send_response(202 if ok else 401)
            self.end_headers()
        elif self.path.startswith('/oauth2/callback'):
            status = 403 if 'scope-denied' in self.path else 500
            self.send_response(status)
            self.send_header('Content-Type', 'text/html')
            self.send_header('X-Internal-Debug', 'SYNTHETIC INTERNAL SECRET')
            self.send_header('Set-Cookie', 'synthetic-internal=do-not-forward; Path=/')
            self.end_headers()
            self.wfile.write(b'missing github user: INTERNAL SYNTHETIC DETAILS')
        elif self.path.startswith('/oauth2/sign_out'):
            State.valid = False
            self.send_response(302)
            self.send_header('Set-Cookie', '__Host-preview_gate=; Max-Age=0; Path=/')
            self.end_headers()
        else:
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b'synthetic gate endpoint')

class App(BaseHTTPRequestHandler):
    def log_message(self, *_): pass
    def do_GET(self):
        State.app_requests.append((self.path, dict(self.headers)))
        payload = {'path': self.path, 'headers': dict(self.headers), 'cookies': self.headers.get_all('Cookie', [])}
        body = json.dumps(payload).encode()
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

def serve(handler):
    server = ThreadingHTTPServer(('127.0.0.1', 0), handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server

def free_port():
    with socket.socket() as s:
        s.bind(('127.0.0.1', 0))
        return s.getsockname()[1]

def request(port, path, headers=None, multiple=None):
    conn = http.client.HTTPConnection('127.0.0.1', port, timeout=4)
    try:
        if multiple is not None:
            conn.putrequest('GET', path)
            for name, value in multiple: conn.putheader(name, value)
            conn.endheaders()
        else:
            conn.request('GET', path, headers=headers or {})
        resp = conn.getresponse()
        return resp.status, dict(resp.getheaders()), resp.read()
    finally:
        conn.close()

def gate_cookie_name(name):
    prefix = '__Host-preview_gate'
    return name == prefix or (name.startswith(prefix + '_') and name[len(prefix)+1:].isdigit())

def check(ok, label):
    if not ok: raise AssertionError(label)
    print('PASS', label)

def main():
    State.valid = True
    State.app_requests = []
    State.auth_cookie_headers = []
    State.auth_authorization = []
    State.auth_decisions = []
    gate, app = serve(Gate), serve(App)
    port = free_port()
    env = dict(os.environ, GATE_ADDR=f'127.0.0.1:{gate.server_port}',
               APP_ADDR=f'127.0.0.1:{app.server_port}',
               PUBLIC_AUTHORITY='preview.xennic.ir')
    version = subprocess.run([CADDY, 'version'], check=True, capture_output=True, text=True).stdout.strip()
    if not version.startswith('v2.11.7 '): raise RuntimeError('Expected Caddy v2.11.7')
    with tempfile.TemporaryDirectory(prefix='xennic-gate-review-') as tmp:
        cfg = Path(tmp) / 'Caddyfile'
        cfg.write_text('{\n admin off\n auto_https off\n}\n'
                       f'http://127.0.0.1:{port} {{\n import {BASE / "routes.caddy"}\n}}\n')
        log = open(Path(tmp) / 'caddy.log', 'w+')
        proc = subprocess.Popen([CADDY, 'run', '--config', str(cfg), '--adapter', 'caddyfile'],
                                cwd=BASE, env=env, stdout=log, stderr=log)
        try:
            for _ in range(100):
                if proc.poll() is not None:
                    log.flush(); log.seek(0); raise RuntimeError('Caddy exited: ' + log.read()[-2000:])
                try: request(port, '/') ; break
                except OSError: time.sleep(.05)
            else: raise RuntimeError('Caddy did not start')
            check(request(port, '/admin')[0] == 302, 'unauthenticated UI redirects')
            check(request(port, '/api/test', {'Authorization':'Bearer synthetic'})[0] == 401,
                  'Bearer alone does not bypass API gate')
            check(request(port, '/graphql')[0] == 401, 'unauthenticated legacy GraphQL path denied')

            before_app = len(State.app_requests)
            before_auth = len(State.auth_decisions)
            status, _, _ = request(port, '/api/graphql')
            check(status == 401 and len(State.app_requests) == before_app,
                  'unauthenticated real Payload /api/graphql path is denied before the app')
            check(len(State.auth_decisions) == before_auth + 1 and State.auth_decisions[-1] is False,
                  'synthetic gate explicitly denies unauthenticated /api/graphql')
            check(request(port, '/media/file')[0] == 302, 'unauthenticated media redirects')
            app_count = len(State.app_requests)
            for url, status_expected in [('/oauth2/callback?code=synthetic', 500),
                                         ('/oauth2/callback?error=scope-denied', 403)]:
                status, headers, body = request(port, url)
                check(status == status_expected, 'callback keeps generic server/client error class')
                check(len(State.app_requests) == app_count, 'callback does not reach application')
                check(b'Sign-in could not be completed' in body and b'INTERNAL' not in body and b'missing github user' not in body,
                      'callback body is understandable and hides provider details')
                check(headers.get('Cache-Control') == 'no-store' and 'X-Internal-Debug' not in headers and 'Set-Cookie' not in headers,
                      'callback omits cacheability, internal headers and upstream cookies')
            check(request(port, '/oauth2/other')[0] == 200 and len(State.app_requests) == app_count,
                  'OAuth endpoints are routed only to gate')

            incoming = {
                'Cookie':'__Host-preview_gate=owner; __Host-preview_gate_0=chunk0; __Host-preview_gate_1=chunk1; payload-token=synthetic; other=keep',
                'Authorization':'Bearer synthetic-payload', 'Forwarded':'for=evil;proto=http',
                'X-Forwarded-User':'attacker', 'X-Auth-Request-Email':'attacker',
                'X-Forwarded-Host':'evil.invalid', 'X-Forwarded-Proto':'http',
                'Origin':'https://preview.xennic.ir', 'Sec-Fetch-Site':'same-origin',
            }
            before_app = len(State.app_requests)
            before_auth = len(State.auth_decisions)
            status, _, body = request(port, '/api/users', incoming)
            app_headers = json.loads(body)['headers']
            check(status == 200 and len(State.auth_decisions) == before_auth + 1 and State.auth_decisions[-1] is True,
                  'valid synthetic gate authorizes request before upstream filtering')
            check(len(State.app_requests) == before_app + 1 and State.app_requests[-1][0] == '/api/users',
                  'authorized API request reaches the upstream app')
            check(app_headers.get('Authorization') == 'Bearer synthetic-payload',
                  'Payload Bearer survives to upstream')
            check('payload-token=synthetic' in app_headers.get('Cookie','') and 'other=keep' in app_headers.get('Cookie',''),
                  'Payload and unrelated cookies survive')
            app_names = [p.strip().partition('=')[0].strip() for p in app_headers.get('Cookie','').split(';')]
            check(not any(gate_cookie_name(n) for n in app_names), 'gate cookie and numeric chunks are removed upstream')
            check(any('__Host-preview_gate=owner' in value for value in State.auth_cookie_headers),
                  'gate receives original cookie before selective upstream stripping')
            check(app_headers.get('Origin') == 'https://preview.xennic.ir' and app_headers.get('Sec-Fetch-Site') == 'same-origin',
                  'Origin and Fetch Metadata preserved')
            check('Forwarded' not in app_headers and 'X-Forwarded-User' not in app_headers and
                  app_headers.get('X-Forwarded-Host') == 'preview.xennic.ir' and
                  app_headers.get('X-Forwarded-Proto') == 'https', 'spoofed forwarding/identity headers removed or rebuilt')

            layouts = [
                '__Host-preview_gate=owner; payload-token=synthetic',
                'payload-token=synthetic; __Host-preview_gate=owner',
                'payload-token=synthetic; __Host-preview_gate=owner; payload-other=abc',
                '__Host-preview_gate=owner; __Host-preview_gate_0=chunk0; __Host-preview_gate_1=chunk1; payload-token=synthetic',
                '__Host-preview_gate=owner; __Host-preview_gate_extra=keep; payload-token=synthetic',
                '  __Host-preview_gate=owner; payload-token=synthetic',
                '__Host-preview_gate=owner; __Host-preview_gate =decoy; payload-token=synthetic',
                'payload-token=synthetic; __Host-preview_gate=owner; __Host-preview_gate\t=decoy; payload-other=abc',
            ]
            parser_cases = []
            for index, value in enumerate(layouts, start=1):
                before_app = len(State.app_requests)
                before_auth = len(State.auth_decisions)
                st, _, b = request(port, '/api/test', {'Cookie':value, 'Authorization':'Bearer synthetic-payload'})
                check(st == 200 and len(State.auth_decisions) == before_auth + 1 and State.auth_decisions[-1] is True,
                      f'cookie sample {index} passes synthetic gate authentication')
                check(len(State.app_requests) == before_app + 1 and State.app_requests[-1][0] == '/api/test',
                      f'cookie sample {index} reaches HTTP filter and upstream app')
                returned_headers = json.loads(b)['headers']
                returned = returned_headers.get('Cookie','')
                names = [p.strip().partition('=')[0].strip() for p in returned.split(';')]
                check('payload-token=synthetic' in returned and not any(gate_cookie_name(n) for n in names),
                      f'cookie sample {index} removes gate value upstream and preserves Payload cookie')
                if '__Host-preview_gate_extra=keep' in value:
                    check('__Host-preview_gate_extra=keep' in returned,
                          'similarly named non-gate cookie is preserved after successful gate auth')
                parser_cases.append({'cookie':returned})

            before_app = len(State.app_requests)
            before_auth = len(State.auth_decisions)
            st, _, b = request(port, '/api/test', multiple=[
                ('Cookie','payload-token=synthetic; __Host-preview_gate=owner'),
                ('Cookie','__Host-preview_gate_0=chunk0; __Host-preview_gate_1=chunk1; other=keep'),
                ('Authorization','Bearer synthetic-payload')])
            multi_cookies = json.loads(b)['cookies']
            check(st == 200 and len(State.auth_decisions) == before_auth + 1 and State.auth_decisions[-1] is True,
                  'multiple Cookie fields pass synthetic gate authentication')
            check(len(State.app_requests) == before_app + 1 and State.app_requests[-1][0] == '/api/test',
                  'multiple Cookie fields reach upstream app')
            check(not any(gate_cookie_name(p.strip().partition('=')[0].strip())
                  for value in multi_cookies for p in value.split(';')), 'all gate cookie values are removed from all upstream Cookie fields')
            check('payload-token=synthetic' in '; '.join(multi_cookies) and 'other=keep' in '; '.join(multi_cookies),
                  'multiple Cookie fields preserve app cookies')
            parser_cases.append({'cookie':'; '.join(multi_cookies)})

            before_app = len(State.app_requests)
            before_auth = len(State.auth_decisions)
            st, _, b = request(port, '/api/graphql', {
                'Cookie':'__Host-preview_gate=owner; payload-token=synthetic',
                'Authorization':'Bearer synthetic-payload',
            })
            graph_headers = json.loads(b)['headers']
            graph_cookies = [p.strip().partition('=')[0].strip()
                             for p in graph_headers.get('Cookie','').split(';')]
            check(st == 200 and len(State.auth_decisions) == before_auth + 1 and State.auth_decisions[-1] is True,
                  'valid gate authorizes actual /api/graphql route')
            check(len(State.app_requests) == before_app + 1 and State.app_requests[-1][0] == '/api/graphql',
                  'authorized /api/graphql request reaches upstream app')
            check(graph_headers.get('Authorization') == 'Bearer synthetic-payload' and
                  'payload-token=synthetic' in graph_headers.get('Cookie','') and
                  not any(gate_cookie_name(name) for name in graph_cookies),
                  '/api/graphql strips gate cookie while preserving Payload Bearer and cookie')

            if os.environ.get('PAYLOAD_PACKAGE_DIR'):
                result = subprocess.run(['node', str(BASE/'test_payload_extraction.mjs')],
                    input=json.dumps(parser_cases), text=True, capture_output=True, check=True)
                print(result.stdout.strip())
            else:
                print('SKIP Payload parser integration: set PAYLOAD_PACKAGE_DIR to Payload 3.91.0 package')
            check(not State.auth_authorization, 'Bearer is not sent to synthetic gate')
            print('SKIP gate outage test: no outage is requested or performed by this test.')
            print('LIMITATION: no OAuth2 Proxy, GitHub, real browser, real Payload server or Docker network tested.')
        finally:
            proc.terminate()
            try: proc.wait(timeout=5)
            except subprocess.TimeoutExpired: proc.kill(); proc.wait()
            gate.shutdown(); gate.server_close(); app.shutdown(); app.server_close(); log.close()

if __name__=='__main__':
    try: main()
    except Exception as exc:
        print('FAIL', type(exc).__name__, file=sys.stderr)
        raise SystemExit(1)
