# بستهٔ موردنیاز دستیار وبسایت برای بازبینی مجدد — نسخهٔ 1.1.1

مبنای دقیق: `feerozmandi/xennic-website@418de2b5b3a272e79a824ccde5411dc25f1002cc`. بسته شامل ۴۰ فایل غیرمحرمانه است؛ هیچ runtime Secret عمدی ندارد. **درخواست: بازبینی ایستا فقط.** هیچ Compose/Caddy/DB، migration/seed، OAuth/GitHub، browser test یا فرمانی روی VPS، gate فعال، DNS یا رایانهٔ مالک اجرا نشود. نسخهٔ 1.1.0 منسوخ و برای اجرا ممنوع است.

## اولویت ۱ — ترتیب DB تازه و شرط توقف

- `RUNBOOK.fa.md` — توالی اجباری readiness → migration صریح → کنترل exit/ledger/shared schema → Staff bootstrap آزمایشی → seed یک‌باره؛ روی هر خطا app/Staff/seed باید متوقف بمانند.
- `scripts/preview-task.mjs` در checkout وبسایت — advisory lock، guard محیط preview، رد DB بدون migration و تأیید baseline؛ لطفاً بررسی کنید دستور Runbook و این wrapper با Compose پایه سازگار است.
- `migrations/index.ts`, `migrations/20261030_163225_baseline.ts`, `scripts/seed.ts` — در checkout وبسایت بررسی شوند؛ آیا migration ledger و shared schema query پیشنهادی کافی است؟ آیا seed با lock/شرط Runbook دقیقاً یک‌بار اجرا می‌شود؟ (wrapper ledger دائمیِ اجرای موفق seed ندارد.)
- `compose.preview.yml` و `compose.payload-lab.override.yml` — healthcheck/`--wait`, `!reset []`, network `internal`, project-volume namespacing، app `ports` merge و publish مؤثر بازبینی شود. فایل Compose مؤثر هنوز resolve نشده است.

## اولویت ۲ — Caddy / gate و Cookie

- `routes.caddy`, `upstream.caddy`, `oauth-gateway.caddy`, `Caddyfile.payload.lab` — مسیرها و preserve/filter headerها، مسیر واقعی `/api/graphql`، Cookie gate در برابر Payload Cookie/Bearer، و `forward_auth` بازبینی شوند.
- `test_caddy_mock.py` — نمونه‌هایی که پیش از رسیدن به Caddy upstream filter به‌علت fixture gate رد می‌شدند اصلاح شده‌اند؛ برای هر مورد test اکنون انتظار دارد gate موفق شود، درخواست به upstream برسد و Cookie gate در header upstream حذف شود. این تست **در این بسته اجرا نشده**.
- `gate_stub.py` — فقط marker مصنوعی را می‌پذیرد؛ امنیت یا احراز هویت واقعی نیست و در network محدود آزمایش است.

## اولویت ۳ — رفتار Payload و آزمون واقعی برنامه

- `test_payload_caddy.mjs` — integration test پیشنهادی برای Payload 3.91.0 در DB/media جدا. فقط Staff تصادفی `example.invalid` و PNG تصادفی می‌نویسد. `/api/graphql`، رسانه (POST، metadata GET و bytes GET)، gate معتبر/غایب، استقلال Payload Bearer/Cookie از gate، logout و login تازه را بررسی می‌کند. اجرا نشده است.
- `VALIDATION.fa.md`, `REVIEW-REPORT.fa.md`, `VERSIONS-DIGESTS.fa.md` — source-level review از Payload `3.91.0` را توضیح می‌دهند: logout همان `sid` را حذف می‌کند، JWT strategy session فعال را می‌سنجد، و `/api/staff/me` برای token لغوشده HTTP 200 با `user:null` برمی‌گرداند. این نتیجه منبع‌خوانی است، نه اجرای server/test.
- `test_payload_extraction.mjs` — unit-style بررسی extractJWT واقعی از Payload package pinشده؛ نتیجهٔ قبلی این تست historical است و در این turn تکرار نشده است.
- `test_payload_browser.js` — اختیاری، خارج از برنامهٔ فعلی؛ host mapping/CA trust را تغییر ندهید.

## اولویت ۴ — موارد باز الزامی

لطفاً در گزارش، هر مورد را «تأیید»، «نیازمند اصلاح» یا «نامعلوم» علامت بزنید:

1. Compose مؤثر با `!reset []` دقیقاً چه پورت‌هایی publish می‌کند؟ آیا direct app port در IPv4، IPv6، host routing یا تنظیم دیگری قابل bypass است؟ در این مرحله هیچ stack اجرا نشود.
2. آیا Caddy `2.11.7` regex filter فقط Cookie پایه و chunkهای عددی gate را حذف می‌کند و تمام layoutهای آزموده‌شونده را به app می‌رساند؟ آیا رفتار چند `Cookie` header درست است؟
3. آیا `/api/graphql` در route واقعی Next/Payload از gate می‌گذرد و GraphQL probe پیشنهادی معتبر است؟
4. آیا upload `POST /api/media`, metadata `GET /api/media/:id` و file bytes URL با baseline/`PREVIEW_ORIGIN` به همین شکل کار می‌کنند؟ statusهای مورد انتظار چیست؟
5. آیا Payload `3.91.0` default `useSessions`, logout و `/me` در مسیر واقعی همین رفتار source-level را دارند؟ لطفاً استدلال با source/pinned test بدهید؛ invalid Bearer را HTTP 401 فرض نکنید.
6. آیا ترتیب Runbook برای migration, verify, Staff bootstrap و one-shot seed درست است؟ آیا query check نیاز به شرط/ستون دیگری دارد؟
7. Gate واقعی برای GitHub چه egress لازم دارد؟ overlay فعلی از stub استفاده می‌کند و network داخلی egress ندارد؛ OAuth/GitHub واقعی آزموده نشده است.
8. provenance/manifest digest برای Caddy/Python و Node/Postgres چگونه مستقل تأیید و pin شود؟ مقادیر موجود فعلاً تأییدنشده‌اند.
9. scope نهایی OAuth و علت callback/account دوم چه دادهٔ غیرمحرمانه‌ای لازم دارد؟ callback `403/500` به‌تنهایی علت را ثابت نمی‌کند؛ لاگ خام، Cookie، token یا OAuth code درخواست نشود.

## فایل‌های اصلاح‌شده در 1.1.1

`README.fa.md`, `CHANGELOG.fa.md`, `RUNBOOK.fa.md`, `FILES-FOR-WEBSITE-ASSISTANT.fa.md`, `REVIEW-REPORT.fa.md`, `VALIDATION.fa.md`, `VERSIONS-DIGESTS.fa.md`, `test_caddy_mock.py`, `test_payload_caddy.mjs`, `MANIFEST.json`, `SHA256SUMS`.

## فایل‌های داخل ZIP/TXT

فهرست کامل و hash هر فایل در `MANIFEST.json` و `SHA256SUMS` است. TXT کنار ZIP export کامل ۴۰ فایل متنی است؛ فایل ZIP با پسوند `.txt` نیست. نسخهٔ `1.1.0` برای اجرا superseded/DO NOT RUN است.

## محدودیت‌هایی که بازبین باید رعایت کند

- هیچ فایل config روی gate فعال apply/reload نشود؛ Compose، stack، migration، seed، test واقعی، OAuth/GitHub، DNS یا VPS اجرا نشود.
- egress واقعی، port bypass، image pull، account دوم، outage با نشست معتبر یا backup/restore روی سرویس مالک آزمایش نشود.
- `read:org` را مجوز App نهایی تلقی نکنید؛ scope نهایی هنوز تأیید نشده است.
- Open Notebook، Hermes یا `[RAG-02]` خارج از دامنه است.
