# بستهٔ بازبینی Xennic Preview Gate

**نسخه:** `1.1.1` — ۲۰۲۶-۱۰-۳۱
**مبنای وبسایت:** `feerozmandi/xennic-website@418de2b5b3a272e79a824ccde5411dc25f1002cc`
**وضعیت:** فقط بازبینی ایستا؛ نه مجوز اجرا، استقرار، یا تغییر زیرساخت.

## هشدار نسخه و اجرا

نسخهٔ `1.1.1` جایگزین بازبینی `1.1.0` است. **نسخهٔ 1.1.0 برای اجرا منسوخ (SUPERSEDED / DO NOT RUN) است.** نسخهٔ 1.1.1 نیز تا دریافت بازبینی دستیار وبسایت، رفع blockerها و تأیید صریح مالک نباید اجرا شود. هیچ stack، migration، seed، Caddy، Docker Compose، OAuth یا آزمون برنامه‌ای در این مرحله راه‌اندازی نشده است.

`oauth2-proxy.example.toml` هنوز scope sentinel `UNAPPROVED_DO_NOT_RUN` دارد و sentinel جلوگیری فنی از startup نیست. `compose.oauth-lab.reference.yml` نیز به‌دلیل project/port/subnet قدیمی `DO NOT RUN` است. `compose.payload-lab.override.yml` فقط gate مصنوعی دارد؛ OAuth/GitHub یا هویت واقعی نیست. هیچ فایل این بسته را روی VPS، gate فعال، DNS یا رایانهٔ مالک اعمال نکنید.

مخزن عمومی است و هر فایل داخل آن برای عموم قابل‌دریافت است. اسکن بسته برای Secretهای شناخته‌شده انجام می‌شود، اما تضمین کشف همهٔ اسرار نیست. فایل env نمونه فقط placeholder دارد؛ هیچ secret، cookie، token، private key یا دادهٔ کاربر واقعی عمداً درج نشده است.

## چه چیزی در 1.1.1 اصلاح شد

- Runbook برای DB تازه، ترتیب اجباری readiness → اجرای صریح migration → کنترل موفقیت migration → bootstrap یک‌بارهٔ Staff آزمایشی → seed یک‌باره، پیش‌شرط‌ها و توقف روی خطا را روشن می‌کند.
- `test_caddy_mock.py` نمونه‌های Cookie را طوری اصلاح می‌کند که gate مصنوعی ابتدا واقعاً درخواست را مجاز کند؛ سپس موفقیت gate، رسیدن به upstream و حذف Cookie gate از هدر upstream assert می‌شود.
- `test_payload_caddy.mjs` رفتار Bearer لغوشده را مطابق منبع Payload `3.91.0` می‌سنجد، login تازه می‌گیرد و `/api/graphql` و upload/metadata/file retrieval رسانه را با gate و بدون gate پوشش می‌دهد؛ تمام داده‌های نوشتنی تستی مصنوعی‌اند.
- وضعیت موارد حل‌نشده — egress واقعی gate به GitHub، Compose مؤثر، دورزدن port برنامه و انتساب digest imageها — صریحاً باز ثبت شده است.
- هیچ اصلاح کدی/مستندی به‌تنهایی به‌عنوان موفقیت runtime گزارش نمی‌شود.

## راهنماها و فایل‌های کلیدی

- [گزارش بازبینی](REVIEW-REPORT.fa.md) — تغییرات، رفتارهای صرفاً استاتیک و blockerهای باز.
- [تغییرات نسخه](CHANGELOG.fa.md) — فایل‌های اصلاح‌شده و تفاوت با 1.1.0.
- [Runbook](RUNBOOK.fa.md) — توالی دقیق DB و مراحل آتیِ قفل‌شده تا بازبینی و مجوز.
- [فهرست دستیار وبسایت](FILES-FOR-WEBSITE-ASSISTANT.fa.md) — درخواست بازبینی ایستا و سؤال‌های باز.
- [وضعیت اعتبارسنجی](VALIDATION.fa.md) — آزمون اجراشده، static review و موارد اجرا‌نشده جداگانه.
- [نسخه‌ها و digestها](VERSIONS-DIGESTS.fa.md) — شناسنامهٔ وابستگی و وضعیت provenance.
- `MANIFEST.json` و `SHA256SUMS` — checksum فایل‌های داخل بسته.

## ترتیب دریافت و بازبینی

۱. به دستیار وبسایت فقط نسخهٔ `1.1.1` را از همان PR عمومی بدهید؛ ابتدا README، changelog، گزارش، Runbook و آزمون‌ها را بخواند.
۲. از بازبین پاسخ روشن برای هر blocker باز بخواهید. تا آن زمان هیچ stack/Compose، OAuth، DNS، browser test، migration یا seed اجرا نشود.
۳. بعد از رفع blocker و تأیید صریح مالک، برنامهٔ آزمون disposable را جداگانه اجرا کنید؛ هیچ‌یک از این مجوزها شامل VPS، gate فعال یا DNS نیست.

## یکپارچگی بسته

پس از استخراج ZIP، در ریشهٔ بسته:

```sh
sha256sum -c SHA256SUMS
python3 verify_bundle.py
```

Checksumها فقط یکپارچگی فایل‌ها را ثابت می‌کنند؛ اصالت image، Compose merge، امنیت شبکه یا رفتار runtime را اثبات نمی‌کنند. فایل TXT تحویل، رکوردهای UTF-8 کامل و hash هر یک از فایل‌های بسته را دارد و **ZIP با پسوند متنی نیست**.
