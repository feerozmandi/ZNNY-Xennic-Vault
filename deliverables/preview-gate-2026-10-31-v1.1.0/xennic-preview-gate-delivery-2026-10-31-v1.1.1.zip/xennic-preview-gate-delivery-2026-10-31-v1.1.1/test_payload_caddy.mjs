// Isolated integration test for REAL Payload 3.91.0 behind Caddy + synthetic gate.
// Requires website commit 418de2b5, a fresh disposable DB/media project, the
// reviewed overlay and a public local Caddy CA. It maps only this Node process
// to 127.0.0.1. Every write uses a random synthetic Staff and synthetic PNG.
// It never targets VPS/public DNS and prints no credentials, cookies, or tokens.
import assert from 'node:assert/strict'
import { randomBytes, randomUUID } from 'node:crypto'
import { readFileSync } from 'node:fs'
import https from 'node:https'

const origin = 'https://preview.xennic.ir'
const hostname = 'preview.xennic.ir'
const caFile = process.env.LAB_CA_FILE
assert(caFile, 'Set LAB_CA_FILE to the public root certificate from the isolated Caddy lab')
const ca = readFileSync(caFile)
const gateCookie = '__Host-preview_gate=synthetic-owner'

function request(path, {method='GET', body, headers={}, withGate=true}={}) {
  return new Promise((resolve, reject) => {
    const outgoing = {Host:hostname, ...headers}
    if (withGate) outgoing.Cookie = [gateCookie, outgoing.Cookie].filter(Boolean).join('; ')
    if (body !== undefined) outgoing['Content-Length'] = Buffer.isBuffer(body) ? body.length : Buffer.byteLength(body)
    const req = https.request({hostname, servername:hostname, port:443, path, method, headers:outgoing,
      ca, rejectUnauthorized:true,
      lookup(_host, options, cb) {
        if (options?.all) cb(null, [{address:'127.0.0.1', family:4}])
        else cb(null, '127.0.0.1', 4)
      },
    }, res => {
      const chunks=[]
      res.on('data', c => chunks.push(c))
      res.on('end', () => resolve({status:res.statusCode, headers:res.headers, body:Buffer.concat(chunks)}))
    })
    req.on('error', reject)
    if (body !== undefined) req.write(body)
    req.end()
  })
}
function check(ok, label) { assert(ok, label); console.log('PASS', label) }
async function waitForGateProxy() {
  for (let attempt = 0; attempt < 60; attempt += 1) {
    try {
      const response = await request('/api/staff/me', {withGate:false})
      if (response.status === 401) return
    } catch {
      // Caddy or the synthetic gate may still be starting; retry only this
      // unauthenticated readiness probe, never a write request.
    }
    await new Promise(resolve => setTimeout(resolve, 250))
  }
  assert.fail('Caddy + synthetic gate did not become ready on loopback')
}
function jsonBody(response) {
  try { return JSON.parse(response.body.toString('utf8')) }
  catch { return {} }
}
function responseCookies(response) {
  return Array.isArray(response.headers['set-cookie']) ? response.headers['set-cookie'] : []
}
function extractPayloadCookie(response) {
  const setCookie = responseCookies(response).find(v => /^payload-token=/.test(v))
  check(Boolean(setCookie), 'Payload cookie passed through proxy')
  check(/(?:^|;)\s*HttpOnly(?:=true)?(?:;|$)/i.test(setCookie), 'Payload cookie HttpOnly')
  check(/(?:^|;)\s*SameSite=Lax(?:;|$)/i.test(setCookie), 'Payload cookie SameSite=Lax')
  check(/(?:^|;)\s*Secure(?:=true)?(?:;|$)/i.test(setCookie), 'Payload cookie Secure')
  check(/(?:^|;)\s*Path=\/(?:;|$)/i.test(setCookie), 'Payload cookie Path=/')
  check(!/(?:^|;)\s*Domain=/i.test(setCookie), 'Payload cookie host-only')
  return setCookie.split(';',1)[0]
}
function mediaMultipart() {
  const boundary = `----xennic-preview-${randomUUID().replaceAll('-', '')}`
  const filename = `synthetic-${randomUUID()}.png`
  const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAADUlEQVR4nGP4z8AAAAMBAQDJ/pLvAAAAAElFTkSuQmCC', 'base64')
  const body = Buffer.concat([
    Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="alt"\r\n\r\nSynthetic preview gate test image\r\n`),
    Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${filename}"\r\nContent-Type: image/png\r\n\r\n`),
    png,
    Buffer.from(`\r\n--${boundary}--\r\n`),
  ])
  return {body, filename, contentType:`multipart/form-data; boundary=${boundary}`}
}

const json = {'Content-Type':'application/json', Origin:origin}
const email = `lab-${randomUUID()}@example.invalid`
let password = randomBytes(32).toString('base64url')
let token = ''
let freshToken = ''
let payloadCookie = ''
let freshPayloadCookie = ''

try {
  await waitForGateProxy()
  let r = await request('/api/staff/me', {withGate:false})
  check(r.status === 401, 'Payload API is denied when the independent gate session is absent')
  r = await request('/admin', {withGate:false})
  check(r.status === 302, 'admin redirects without synthetic gate marker')

  r = await request('/api/staff/first-register', {method:'POST', headers:json,
    body:JSON.stringify({name:'Synthetic Preview Test', email, password})})
  check(r.status === 200, 'fresh disposable DB creates one synthetic test Staff')

  r = await request('/api/staff/login', {method:'POST',
    headers:{'Content-Type':'application/json', Origin:'https://untrusted.example.invalid'},
    body:JSON.stringify({email,password})})
  check(r.status === 403 && !responseCookies(r).some(v => /^payload-token=/.test(v)),
        'untrusted-Origin login rejected without issuing Payload cookie')

  r = await request('/api/staff/login', {method:'POST', headers:json, body:JSON.stringify({email,password})})
  check(r.status === 200, 'synthetic Staff login succeeds through the synthetic gate')
  let loginBody = jsonBody(r)
  token = typeof loginBody.token === 'string' ? loginBody.token : ''
  check(Boolean(token), 'Payload returned a synthetic Bearer token')
  payloadCookie = extractPayloadCookie(r)

  r = await request('/api/staff/me', {headers:{Cookie:payloadCookie, Origin:origin}})
  let cookieMe = jsonBody(r)
  check(r.status === 200 && Boolean(cookieMe.user?.email), 'Payload Cookie session works through Caddy')

  r = await request('/api/staff/me', {headers:{Cookie:payloadCookie, Origin:'https://untrusted.example.invalid'}})
  const untrustedMe = jsonBody(r)
  check(r.status === 200 && !untrustedMe.user,
        'Payload returns no authenticated user for an untrusted-Origin Cookie request')

  r = await request('/api/staff/logout', {method:'POST', headers:{Cookie:payloadCookie, Origin:origin}})
  check(r.status === 200, 'Payload logout succeeds through Caddy')
  const expired = responseCookies(r).find(v => /^payload-token=/.test(v))
  check(Boolean(expired) && /(?:Max-Age=0|Expires=)/i.test(expired), 'Payload logout expires its cookie')

  // Payload 3.91.0 uses sessions by default in this collection. Logout removes
  // the current sid; JWT auth then resolves to no user. /api/staff/me intentionally
  // returns HTTP 200 with {user:null}; it is not asserted as HTTP 401 here.
  r = await request('/api/staff/me', {headers:{Authorization:`Bearer ${token}`, Origin:origin}})
  const staleBearerMe = jsonBody(r)
  check(r.status === 200 && staleBearerMe.user === null,
        'revoked Payload Bearer is no longer authenticated after logout (HTTP 200, user:null)')

  // A fresh Payload login is required for any later test that needs Payload auth;
  // the independent synthetic gate cookie is added by request() separately.
  r = await request('/api/staff/login', {method:'POST', headers:json, body:JSON.stringify({email,password})})
  check(r.status === 200, 'fresh Payload session is established after revoked-token check')
  loginBody = jsonBody(r)
  freshToken = typeof loginBody.token === 'string' ? loginBody.token : ''
  check(Boolean(freshToken) && freshToken !== token, 'fresh login issued a distinct Payload Bearer token')
  freshPayloadCookie = extractPayloadCookie(r)
  token = ''

  r = await request('/api/staff/me', {headers:{Authorization:`Bearer ${freshToken}`, Origin:origin}})
  const freshBearerMe = jsonBody(r)
  check(r.status === 200 && Boolean(freshBearerMe.user?.email),
        'new Payload Bearer authenticates after login; gate session remains independent')

  const graphqlBody = JSON.stringify({query:'query PreviewGateProbe { __typename }'})
  r = await request('/api/graphql', {method:'POST', headers:json, body:graphqlBody})
  const graph = jsonBody(r)
  check(r.status === 200 && Boolean(graph.data?.__typename),
        'real Payload /api/graphql query succeeds with the synthetic gate')

  r = await request('/api/graphql', {method:'POST', withGate:false,
    headers:{...json, Authorization:`Bearer ${freshToken}`, Cookie:freshPayloadCookie}, body:graphqlBody})
  check(r.status === 401,
        'valid Payload Bearer and Cookie cannot bypass the missing independent gate on /api/graphql')

  const upload = mediaMultipart()
  const uploadHeaders = {'Content-Type':upload.contentType, Origin:origin, Authorization:`Bearer ${freshToken}`}
  r = await request('/api/media', {method:'POST', withGate:false, headers:uploadHeaders, body:upload.body})
  check(r.status === 401,
        'synthetic media upload is denied without gate even when Payload Bearer is valid')

  r = await request('/api/media', {method:'POST', headers:{'Content-Type':upload.contentType, Origin:origin}, body:upload.body})
  check(r.status === 401 || r.status === 403,
        'valid gate alone does not authorize Staff-only media upload without Payload session')

  r = await request('/api/media', {method:'POST', headers:uploadHeaders, body:upload.body})
  check(r.status >= 200 && r.status < 300, 'synthetic PNG media upload succeeds with both gate and Payload Staff sessions')
  const uploadResponse = jsonBody(r)
  const mediaDoc = uploadResponse.doc ?? uploadResponse
  check(mediaDoc && mediaDoc.id !== undefined, 'Payload returns the synthetic media document id')

  const mediaID = encodeURIComponent(String(mediaDoc.id))
  r = await request(`/api/media/${mediaID}`, {headers:{Authorization:`Bearer ${freshToken}`, Origin:origin}})
  const mediaMetadataResponse = jsonBody(r)
  const retrievedMedia = mediaMetadataResponse.doc ?? mediaMetadataResponse
  check(r.status === 200 && String(retrievedMedia.id) === String(mediaDoc.id),
        'Payload media metadata is retrievable through the gate')

  let mediaURL = typeof mediaDoc.url === 'string' && mediaDoc.url
    ? new URL(mediaDoc.url, origin)
    : new URL(`/media/${encodeURIComponent(String(mediaDoc.filename))}`, origin)
  check(mediaURL.origin === origin && mediaURL.pathname.startsWith('/media/'),
        'synthetic media URL stays on the reviewed preview origin')
  const mediaPath = `${mediaURL.pathname}${mediaURL.search}`
  r = await request(mediaPath, {headers:{Authorization:`Bearer ${freshToken}`, Origin:origin}})
  check(r.status === 200 && r.body.length > 0, 'uploaded synthetic media bytes are retrievable through the gate')

  r = await request(`/api/media/${mediaID}`, {withGate:false,
    headers:{Authorization:`Bearer ${freshToken}`, Origin:origin}})
  check(r.status === 401, 'media metadata retrieval is denied without the independent gate')
  r = await request(mediaPath, {withGate:false,
    headers:{Authorization:`Bearer ${freshToken}`, Origin:origin}})
  check(r.status === 401, 'uploaded media bytes are denied without the independent gate')

  console.log('LIMITATION: synthetic gate only; no OAuth2 Proxy or GitHub account was tested.')
  console.log('LIMITATION: this script is an unexecuted integration test until approved and run on the disposable local stack.')
} finally {
  password = ''
  token = ''
  freshToken = ''
  payloadCookie = ''
  freshPayloadCookie = ''
}
