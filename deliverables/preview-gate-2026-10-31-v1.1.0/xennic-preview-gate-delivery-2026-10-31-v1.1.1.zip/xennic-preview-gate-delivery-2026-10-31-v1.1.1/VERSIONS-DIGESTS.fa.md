# نسخه‌ها، digestها و منشأ — بستهٔ 1.1.1

**مبنای وبسایت:** `feerozmandi/xennic-website@418de2b5b3a272e79a824ccde5411dc25f1002cc` (PR #10 ادغام‌شده). این commit را با شاخهٔ جاری وبسایت اشتباه نگیرید. نسخهٔ 1.1.0 برای اجرا superseded/DO NOT RUN است.

`compose.preview.yml` داخل بسته از همان baseline گرفته شده است؛ SHA256 شناخته‌شدهٔ فایل `e00963aed6cd1b6d87a27af55b71f662304097a338e519d7f286dcbc3c40918c`. در اجرای آتی build context باید از checkout سایت دقیق باشد، نه از کپی داخل ZIP.

## وابستگی‌ها و image referenceهای موجود

| مؤلفه | نسخه/مرجع | digest / شناسنامه | وضعیت در 1.1.1 |
|---|---|---|---|
| Payload CMS | `3.91.0` | npm tarball SHA256 `3d93c82261fde3d01877c036b64f5fc8f342a6c97192402725d782cb7c50eec3`; SRI `sha512-EF+PXc8iSuo561f82SnAY5YB8Ix6LDN4Xe4ndef0iLDNPkdEykq1vc1mgo82/HsZ4ljSv9u/wP6iP5hyIpM+wA==`; npm shasum `91fddbf74ab60484d9298a83ffab67e4ceab751c` | Tarball بررسی source شد؛ extraction parser test قبلاً در نسخهٔ قبل اجرا شده، ولی در 1.1.1 تکرار نشده؛ server/DB runtime انجام نشده است. |
| Node base image | `node:22.22.3-bookworm-slim` | digest ثبت نشده | از Dockerfile baseline خوانده شد؛ provenance/registry digest تأیید نشده. |
| PostgreSQL | `postgres:16.14-bookworm` | digest ثبت نشده | از Compose baseline خوانده شد؛ provenance/registry digest تأیید نشده. |
| Caddy | `caddy:2.11.7@sha256:36c24ad91a7ff7bc4c87fe22bfa8df3c4b18da0773d73fc12ee2c52b98c0bb7e` | مقدار داخل YAML | registry OCI manifest/platform مستقل مقایسه نشده؛ **تأییدنشده**. Caddy binary/config/test اجرا نشده. |
| OAuth2 Proxy | `quay.io/oauth2-proxy/oauth2-proxy:v7.15.5@sha256:8498b0d0ef0a7b29686414000a08aee467f02d0299c9ed1e006a8f33fc017916` | مقدار داخل Compose مرجع قدیمی | **تأییدنشده**؛ image pull/run انجام نشده. Source file همان tag جداگانه hash شده، اما hash source image digest را ثابت نمی‌کند. |
| Python test gate | `python:3.12.8-alpine@sha256:ba13ef990f6e5d13014e9e8d04c02a8fdb0fe53d6dccf6e19147f316e6cc3a84` | مقدار داخل overlay | registry/platform مستقل تأیید نشده؛ **تأییدنشده**. |
| Docker Compose | حداقل `v2.24.4` پیشنهادی برای `!reset []` | نسخهٔ میزبان نامعلوم | config/merge اجرا نشده؛ Compose مؤثر و port mapping blocker باز است. |
| Go policy test | `go 1.23` | source methodهای pinشده با SHA256 | Go test اجرا نشده. |

هیچ registry image pull/container اجرا نشده است. digestهایی که در YAML دیده می‌شوند فعلاً فقط مقادیر نوشتاری‌اند؛ آن‌ها را provenance تأییدشده تلقی نکنید. پیش از مجوز هر stack باید digest همان tag و platform از registry معتبر مستقل resolve و بازبینی شود. Node/Postgres در baseline tag-only هستند و digest pin ندارند.

## Payload 3.91.0 — شواهد منبع برای logout/Bearer

منبع package در `https://registry.npmjs.org/payload/-/payload-3.91.0.tgz` با SRI و SHA بالا بررسی شد. نکته‌های مربوط به آزمون:

- `dist/collections/config/defaults.js`: مقدار پیش‌فرض `useSessions: true`.
- `dist/auth/operations/logout.js`: در logout عادی، session با id برابر `req.user._sid` از user session list حذف می‌شود.
- `dist/auth/strategies/jwt.js`: پس از verify JWT، `sid` باید در sessionهای فعال کاربر باشد؛ اگر نباشد، strategy `user:null` برمی‌گرداند.
- `dist/auth/endpoints/me.js` و `dist/auth/operations/me.js`: `/api/staff/me` برای این حالت HTTP 200 و body با `user:null` می‌دهد. تست 1.1.1 همین قرارداد را assert می‌کند و سپس برای آزمون auth بعدی login تازه می‌گیرد.
- `dist/auth/endpoints/logout.js`: logout کوکی را expire می‌کند؛ cookie expiry و Bearer revocation دو رفتار مستقل‌اند.

این‌ها source review از Payload pinشده‌اند، نه آزمون سرور سایت. اگر dependency یا کد تغییر کند، این نتیجه را به نسخهٔ جدید تعمیم ندهید.

## OAuth2 Proxy source

- فایل: `providers/github.go` از tag `v7.15.5`.
- tag object: `6e4bd00eea928c0268871954000f1f4fa8c91d30`.
- SHA256 source: `03aee25d95c40af66cdbe932eca288f594621c2ee40696ce88b03be45cfa075e`.
- کپی در bundle: `provider-policy-test/testdata/github.v7.15.5.go.txt`; `generate.py` پیش از تولید آن hash را کنترل می‌کند.
- نه image digest، نه GitHub egress و نه OAuth callback واقعی از این source hash اثبات نمی‌شود.

## Blockerهای provenance و شبکه

1. **Egress GitHub:** overlay فعلی gate stub دارد و `internal: true` است؛ در آن هیچ egress واقعی به GitHub یا OAuth وجود ندارد. نیاز/allowlist egress برای gate واقعی باز است.
2. **Compose مؤثر:** merge فایل‌های base/override، `!reset []`, `ports`, network, volumes و healthcheck با Docker Compose اجرا/تأیید نشده.
3. **Port bypass:** YAML قصد حذف publish مستقیم app و loopback-only Caddy را دارد، اما bypass در merged config، IPv4/IPv6 یا مسیر host runtime آزموده نشده.
4. **Image digest attribution:** Caddy/Python digestها نوشته شده‌اند ولی تأیید نشده‌اند؛ Node/Postgres pin نشده‌اند. بازبینی دستیار وبسایت و مالک باید پیش از اجرای stack این مورد را حل کند.

## منابع عمومی

- Website baseline: `https://github.com/feerozmandi/xennic-website/commit/418de2b5b3a272e79a824ccde5411dc25f1002cc`
- Website PR #10: `https://github.com/feerozmandi/xennic-website/pull/10`
- Payload npm package: `https://registry.npmjs.org/payload/-/payload-3.91.0.tgz`
- OAuth2 Proxy GitHub provider `v7.15.5`: `https://github.com/oauth2-proxy/oauth2-proxy/blob/v7.15.5/providers/github.go`
- OAuth2 Proxy release `v7.15.5`: `https://github.com/oauth2-proxy/oauth2-proxy/releases/tag/v7.15.5`
- Caddy reverse_proxy header directives: `https://caddyserver.com/docs/caddyfile/directives/reverse_proxy`
- Docker Compose merge tags: `https://docs.docker.com/reference/compose-file/merge/`
