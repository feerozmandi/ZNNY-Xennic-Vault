# گزارش بازبینی اصلاحی — Xennic Preview Gate `1.1.1`

**مبنای دقیق وبسایت:** `feerozmandi/xennic-website@418de2b5b3a272e79a824ccde5411dc25f1002cc`
**دامنهٔ نسخه:** تحویل عمومی برای بازبینی دستیار وبسایت؛ بدون تغییر gate فعال، VPS، DNS یا سرویس مالک.
**وضعیت:** فقط بازبینی. نسخهٔ `1.1.0` برای اجرا `SUPERSEDED / DO NOT RUN` است. نسخهٔ `1.1.1` نیز تا رفع blockerها و تأیید صریح مالک نباید اجرا شود.

## خلاصهٔ تصمیم

نسخهٔ 1.1.1 اصلاحات متنی و تستی لازم را اضافه می‌کند؛ این به‌معنای رفع runtime blocker یا تأیید استقرار نیست. در این نشست هیچ Compose/stack، Caddy، Payload server، Postgres، migration، seed، OAuth/GitHub یا آزمون برنامه‌ای اجرا نشده است. هیچ VPS، DNS یا gate فعال تغییر نکرده است.

**درخواست بعدی:** ابتدا همین نسخه از PR عمومی برای بازبینی ایستا به دستیار وبسایت ارائه شود. تا پاسخ او و رفع موارد بخش «Blockerهای باز»، stack یکپارچه اجرا نشود.

## اصلاحات نسخهٔ 1.1.1

- Runbook اکنون DB تازه را با ترتیب اجباری و قابل توقف مشخص می‌کند: PostgreSQL readiness → اجرای صریح `preview:migrate` → کنترل exit code و verification read-only → bootstrap یک‌بارهٔ Staff آزمایشی → seed یک‌باره. شکست/عدم قطعیت migration جلوی app، Staff و seed را می‌گیرد.
- تست Caddy mock برای نمونه‌های Cookie که gate fixture پیش از فیلتر HTTP رد می‌کرد اصلاح شد. هر نمونهٔ موردنظر حالا یک gate cookie معتبر دارد و test جداگانه موفقیت gate، رسیدن درخواست به upstream و حذف cookie gate از header upstream را assert می‌کند.
- تست Payload واقعیِ پیشنهادی برای `/api/graphql` و media اضافه/گسترش داده شد: درخواست بدون gate با Payload Bearer/Cookie معتبر نیز باید در gate متوقف شود؛ آپلود synthetic با هر دو session، metadata و bytes retrieval، و denial بدون gate پوشش داده شده‌اند. اجرا نشده است.
- رفتار Bearer بعد از Payload logout به source pinشدهٔ Payload `3.91.0` متصل شد؛ پس از logout برای آزمون‌های بعدی login تازه گرفته می‌شود. نشست Payload از gate marker مستقل ارزیابی می‌شود.
- egress واقعی GitHub، Compose مؤثر، bypass مستقیم app و digestها به‌عنوان باز/تأییدنشده ثبت شدند؛ هیچ‌کدام رفع‌شده فرض نشده‌اند.

## بررسی source-level Payload `3.91.0` — نه runtime

مبنای سایت dependency دقیق `payload: 3.91.0` دارد. کد همان npm tarball بررسی شد (SRI/SHA در `VERSIONS-DIGESTS.fa.md`):

1. پیش‌فرض auth collection در `dist/collections/config/defaults.js` برابر `useSessions: true` است؛ پیکربندی Staff در baseline overrideای برای خاموش‌کردن session ندارد.
2. `dist/auth/operations/logout.js` در logout عادی session با id برابر `req.user._sid` را از session list حذف می‌کند.
3. `dist/auth/strategies/jwt.js` پس از verify توکن، برای collection دارای session، وجود `sid` در sessionهای فعلی را لازم می‌داند؛ در صورت نبود session نتیجهٔ strategy `user:null` است.
4. `/api/staff/me` در `dist/auth/endpoints/me.js` پاسخ HTTP `200` می‌دهد؛ `meOperation` در نبود `req.user` نتیجهٔ `{user:null}` می‌دهد. بنابراین test نباید برای Bearer لغوشده الزاماً `401` مطالبه کند؛ انتظار منطبق با source، `200` و `user:null` است.
5. logout endpoint cookie را expire می‌کند. این response به‌تنهایی دربارهٔ revocation Bearer دلالت ندارد؛ بررسی session server-side مورد نیاز است.

این‌ها **نتیجهٔ خواندن source ثابت** هستند، نه آزمون endpoint، DB یا اجرای full Payload. تأیید runtime هنوز اجرا نشده و تست یکپارچه فقط پس از بازبینی/مجوز در DB disposable انجام می‌شود.

## طرح Caddy / مسیرها — فقط فایل‌های candidate

- `routes.caddy` matcher `/api /api/* /graphql /graphql/*` را برای `forward_auth` تعریف می‌کند؛ `/api/graphql` از نظر متن config داخل matcher است. رفتار واقعی Caddy هنوز اجرا نشده.
- مسیر `/oauth2/*` فقط به gate upstream فرستاده می‌شود؛ callback 4xx/5xx به پیام عمومی و `no-store` تبدیل می‌شود. OAuth callback واقعی بررسی نشده.
- `upstream.caddy` به‌قصد حذف فقط Cookieهای `__Host-preview_gate` و chunkهای عددی، و حفظ Payload Cookie/Bearer، Origin و Fetch Metadata نوشته شده است. mock test اکنون gate success، upstream reach و header پس از filter را برای نمونه‌ها assert می‌کند؛ Caddy binary در این نشست اجرا نشده.
- overlay متنی `ports: !reset []` برای حذف publish پورت app دارد و Caddy را روی `127.0.0.1:443` تعریف می‌کند؛ Compose merge و پورت مؤثر از YAML به‌تنهایی اثبات نشده‌اند.
- overlay شبکهٔ `internal: true` و `gate_stub.py` را دارد؛ stub فقط marker مصنوعی را می‌پذیرد. این نه OAuth است و نه کنترل هویت امن. چون شبکه internal است، egress واقعی GitHub در این تست وجود ندارد.

## آزمون‌های تحویلی و هدفشان

1. `test_caddy_mock.py` — route/Cookie filtering با Caddy و upstream/gate محلی مصنوعی؛ اکنون برای هر Cookie موردنظر success gate، رسیدن به app و حذف gate cookie assert می‌شود. در این بسته اجرا نشده است.
2. `test_payload_caddy.mjs` — integration test پیشنهادی برای Postgres/Media جدا و Payload `3.91.0`; first-register تصادفی، ورود/خروج، Bearer قدیمی، login تازه، GraphQL، upload و retrieval رسانه با و بدون gate. تمام writeهای **خود آزمون** یک Staff `example.invalid` و یک PNG مصنوعی‌اند. اجرا نشده است.
3. `test_payload_extraction.mjs` — آزمون parser Payload واقعی؛ اجرای تاریخی پیشین با tarball و headerهای synthetic در نسخهٔ قبل ثبت شده، اما در نسخهٔ 1.1.1 تکرار نشده است.
4. `provider-policy-test/` — منبع GitHub provider از OAuth2 Proxy `v7.15.5` را pin می‌کند؛ تست Go و GitHub login واقعی اجرا نشده‌اند.
5. `test_payload_browser.js` — اختیاری و خارج از برنامهٔ فعلی؛ هیچ host mapping/CA trust روی سیستم تغییر نکرده.

تفکیک دقیق syntax/static/package checks از runtime در `VALIDATION.fa.md` آمده است. عبارت «تست اضافه شد» به معنی «تست موفق شد» نیست.

## Blockerهای باز — برای بازبین صریحاً تعیین تکلیف شود

| مورد | وضعیت فعلی | چه چیزی هنوز لازم است |
|---|---|---|
| egress از gate واقعی به GitHub | باز؛ در overlay gate مصنوعی و network داخلی بدون egress است | نیاز/مقصد egress واقعی OAuth باید طراحی، allowlist و در محیط مجاز بررسی شود؛ این نسخه آن را آزمایش نمی‌کند. |
| Compose مؤثر | باز؛ `docker compose config`/merge اجرا نشده | Compose version و config نهایی با secrets پنهان، service/network/volume/ports review شود. |
| bypass مستقیم app | اثبات نشده؛ فایل override قصد حذف publish port را دارد | merged config، IPv4/IPv6 و مسیرهای host/port باید جداگانه در محیط disposable و پس از مجوز سنجیده شوند. تا آن زمان هیچ ادعای «بدون bypass» نداریم. |
| image digest/provenance | تأییدنشده؛ Caddy/Python مقادیر ثبت‌شده دارند؛ Node/Postgres tag-only هستند | manifest همان platform/tag از registry معتبر مستقل resolve و ثبت شود؛ در حال حاضر overlay اجرا نشود. |
| Staff bootstrap واقعی | خارج از scope؛ test فقط Staff مصنوعی را پشت Caddy loopback/stub ایجاد می‌کند | gate واقعی، روش تحویل credential، identity مالک و بازیابی باید جداگانه تأیید شوند. local stub مرز امنیتی production نیست. |
| Compose internal network | رفتار runtime نامعلوم | روشن شود internal network، healthcheck، build و app در آن دقیقاً چه رفتاری دارند؛ عدم egress را با دسترسی GitHub اشتباه نگیرید. |
| OAuth scope و account دوم | باز/نامعلوم | scope نهایی و تفکیک account policy از provider/API failure به دادهٔ redacted و مجوز جدا نیاز دارد. callback عمومی علت را ثابت نمی‌کند. |
| DNS/TLS، backup/restore و ظرفیت | آزموده نشده | بازبینی زیرساخت و آزمون مجاز جدا لازم است؛ بدون تغییر DNS/VPS در این بسته. |

## محدودیت و عدم تغییر

- هیچ Caddy/OAuth/Compose config روی gate فعال apply/reload نشده است.
- هیچ stack، DB، migration، seed، browser، OAuth/GitHub، image pull، VPS یا DNS اجرا/تغییر نشده است.
- checksum آرشیو و testهای syntax تنها یکپارچگی/ساختار را می‌سنجند و security/runtime را ثابت نمی‌کنند.
- Seed سایت محتوای preview مصوب را در صورت اجرای آتی روی DB disposable یک بار می‌نویسد؛ writeهای integration test خودشان فقط دادهٔ Staff/PNG مصنوعی است. هر دو باید از محیط عملیاتی جدا بمانند.
