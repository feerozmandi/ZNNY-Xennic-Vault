# وضعیت اعتبارسنجی بستهٔ `1.1.1`

**هیچ stack یا آزمون integration/runtime برنامه در تهیهٔ این نسخه اجرا نشده است.** Caddy، Docker Compose stack، Payload/Postgres server، migration، seed، OAuth/GitHub، browser، VPS، DNS و gate فعال راه‌اندازی/تغییر نشده‌اند. دو test اصلی (`test_caddy_mock.py`, `test_payload_caddy.mjs`) اصلاح/تحویل شده‌اند، اما اجرا نشده‌اند؛ test نوشته‌شده را موفقیت runtime تلقی نکنید.

## source-level review (نه آزمون)

کد npm tarball دقیق Payload `3.91.0` که در baseline سایت pin است، به‌صورت خواندنی بررسی شد:

- default `useSessions` برابر true است.
- logout عادی همان `sid` را از session list کاربر حذف می‌کند.
- JWT strategy وجود `sid` فعال را لازم می‌داند و در نبود آن `user:null` می‌سازد.
- `/api/staff/me` برای این حالت HTTP 200 می‌دهد؛ انتظار body `user:null` است، نه فرض 401.
- logout handler cookie را expire می‌کند؛ این به‌تنهایی revocation Bearer را ثابت نمی‌کند.

این نتیجه فقط برای source نسخهٔ دقیق pinشده است؛ سرور/DB سایت اجرا نشده است.

## بررسی‌های اجراشده در این turn

- Python in-memory syntax check برای ۸ فایل اسکریپت — PASS؛ هیچ `__pycache__` تولید نشد.
- `node --check` برای ۳ فایل JS/MJS — PASS؛ فایل‌ها اجرا نشدند.
- `bash -n` برای ۱۷ بلوک shell در Runbook — PASS؛ هیچ command اجرا نشد.
- `test_payload_extraction.mjs` با package واقعی Payload `3.91.0` unpackشده و ۳ Cookie layout/Bearer مصنوعی — PASS. این فقط parser/token-extraction code است؛ logout، HTTP endpoint، DB یا session revocation را نمی‌آزماید.
- `verify_bundle.py` — PASS؛ ساختار، placeholder-only env، high-confidence secret patterns، guardrailهای متنی، manifest و ۳۹ ورودی SHA256 را کنترل کرد.
- ZIP و sidecar SHA256 — PASS؛ `unzip -t` موفق، همهٔ ۴۰ ورودی ZIP byte-for-byte با source برابر، و همهٔ ۴۰ رکورد TXT با بایت/hash فایل متناظر برابر بودند.

این بررسی‌ها فقط syntax، parser محدود و یکپارچگی/محتوای بسته را پوشش می‌دهند؛ هیچ‌کدام runtime preview را ثابت نمی‌کنند.

## آزمون‌هایی که اجرا نشده‌اند

- `test_caddy_mock.py`, `check_caddy_config.py` — Caddy `2.11.7` اجرا نشده؛ هیچ claim دربارهٔ route/runtime filter نداریم.
- `test_payload_caddy.mjs` — Payload/Postgres/Caddy overlay اجرا نشده؛ `/api/graphql`, first-register/logout, revoked Bearer, media upload/metadata/file retrieval و gate denial تأیید runtime نشده‌اند.
- Compose `config`/merge, `build`, `up`, health, port exposure, egress و volume behavior — اجرا نشده‌اند. Stack پیش از review/approval ممنوع است.
- `preview:migrate`, SQL verification, Staff bootstrap و `preview:seed` — اجرا نشده‌اند.
- Go provider tests، OAuth/GitHub واقعی، account دوم، outage معتبر، browser/CA، DNS/TLS، VPS، backup/restore و load — اجرا نشده‌اند.
- image digestها از registry مستقل تأیید نشده‌اند؛ Caddy/Python values تأییدنشده‌اند؛ Node/Postgres tag-only هستند.

## محدودهٔ ادعا

`node --check`/Python compile syntax را می‌سنجند، نه رفتار. parser test از Payload package، server/API/auth/session lifecycle را ثابت نمی‌کند. source review با اجرای endpoint یکی نیست. Caddy mock test code و تغییر Runbook مساوی PASS runtime نیست. Checksumها یکپارچگی فایل‌ها را می‌سنجند؛ secret scan تضمین کشف همهٔ موارد نیست. blockerها در `REVIEW-REPORT.fa.md` باز هستند.
