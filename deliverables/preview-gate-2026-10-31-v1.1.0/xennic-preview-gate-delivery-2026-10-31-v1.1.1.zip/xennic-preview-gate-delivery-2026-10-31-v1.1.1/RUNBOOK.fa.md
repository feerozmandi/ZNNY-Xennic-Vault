# Runbook بازبینی و آزمون محدود — فقط پس از تأیید جداگانه

## وضعیت فعلی: توقف

**نسخهٔ 1.1.1 برای بازبینی دستیار وبسایت است، نه مجوز اجرا.** ابتدا فقط فایل‌ها را بررسی کنید. تا ثبت پاسخ بازبین، رفع blockerها، تأیید digestهای image و مجوز صریح مالک، هیچ مرحلهٔ سرویس‌دار زیر اجرا نشود. در این نشست هیچ stack، Compose، Caddy، Payload server، migration یا seed اجرا نشده است.

این Runbook هرگز مجوز تغییر VPS، DNS، gate فعال، firewall، پورت عمومی یا رایانهٔ مالک نیست. OAuth/GitHub واقعی و فایل `compose.oauth-lab.reference.yml` خارج از دامنه و `DO NOT RUN` هستند. اجرای آتی فقط برای checkout مستقل وبسایت و DB/media disposable با دادهٔ آزمایشی است.

## مرحلهٔ صفر — کنترل بسته، کاملاً خواندنی

پس از دریافت ZIP و استخراج آن، در ریشهٔ بسته:

```sh
sha256sum -c SHA256SUMS
python3 verify_bundle.py
```

Checksum خود ZIP را جداگانه با sidecar آن مقایسه کنید. ابتدا `README.fa.md`، `CHANGELOG.fa.md`، `REVIEW-REPORT.fa.md`، `VALIDATION.fa.md` و این Runbook را بخوانید. نسخهٔ `1.1.0` منسوخ و برای اجرا ممنوع است؛ فقط `1.1.1` را برای بازبینی به دستیار وبسایت بدهید.

## مرحلهٔ یک — پیش‌نیازها (پس از بازبینی ایستا و مجوز جداگانه)

در checkout مستقل وبسایت، بدون تغییر شاخه یا فایل، commit مبنا را فقط بخوانید:

```sh
git -C /path/to/xennic-website rev-parse HEAD
```

مقدار لازم: `418de2b5b3a272e79a824ccde5411dc25f1002cc`. اگر checkout متفاوت است، توقف کنید. آزمون به Node `22.22.3`، Payload `3.91.0`، PostgreSQL `16.14`، Caddy `2.11.7` و Docker Compose v2.24.4+ (برای `!reset`) طراحی شده است؛ نسخه/منشأ imageها و Compose مؤثر هنوز تأیید نشده و این‌ها blocker باقی می‌مانند.

همهٔ مراحل سرویس‌دار فقط با تأیید صریح مالک و پس از بازبینی دستیار وبسایت مجازند. پیش از آن‌ها، نام project/volume، پورت loopback 443، egress، دسترسی شبکه و مقصد فایل‌ها باید مستقل بررسی شود. چیزی را برای آزادکردن پورت متوقف نکنید.

## مرحلهٔ دو — بررسی‌های بی‌سرویس (فقط پس از بازبینی)

این‌ها صرفاً syntax/integrity هستند؛ آزمون برنامه یا Compose merge نیستند. روی رایانهٔ مالک نیز پیش از بازبینی اجرا نشوند.

```sh
python3 - <<'PY'
from pathlib import Path
for name in ['check_caddy_config.py','test_caddy_mock.py','fixture.py','gate_stub.py','prepare_lab_config.py','prepare_payload_lab_env.py','provider-policy-test/generate.py']:
    compile(Path(name).read_text(), name, 'exec')
print('PASS Python syntax (in-memory; no __pycache__ written)')
PY
node --check test_payload_extraction.mjs
node --check test_payload_caddy.mjs
node --check test_payload_browser.js
python3 verify_bundle.py
```

`prepare_lab_config.py` و `prepare_payload_lab_env.py` فایل خصوصی خارج از بسته می‌سازند؛ آن‌ها را با این مرحله اجرا نکنید. `provider-policy-test/generate.py` منبع ثابت را بررسی و کد Go تولید می‌کند؛ `go test ./...` فقط پس از بازبینی و مجوز جداگانه انجام شود.

آزمون parser مستقل با Payload tarball دقیق `3.91.0` در صورت نیاز:

```sh
printf '%s' '[{"cookie":"payload-token=synthetic; other=keep"},{"cookie":"; payload-token=synthetic; ; other=keep"}]' \
  | PAYLOAD_PACKAGE_DIR=/path/to/xennic-website/node_modules/payload node test_payload_extraction.mjs
```

فقط دادهٔ ساختگی استفاده شود. اگر نسخهٔ package دقیق نیست یا import شکست خورد، توقف کنید؛ dependencyها را به‌روزرسانی نکنید.

## مرحلهٔ سه — Caddy mock روی loopback (اجرا فقط با مجوز)

این آزمون Caddy `2.11.7` و دو mock محلی را روی loopback اجرا می‌کند؛ نه OAuth2 Proxy، نه GitHub، نه Payload server و نه شبکهٔ خارجی. آزمون جدید برای هر نمونهٔ Cookie موفقیت gate، رسیدن درخواست به upstream و حذف Cookie gate را جداگانه assert می‌کند.

```sh
CADDY_BIN=/path/to/caddy-2.11.7 python3 test_caddy_mock.py
CADDY_BIN=/path/to/caddy-2.11.7 python3 check_caddy_config.py
```

Caddy config و تست در این تحویل اجرا نشده‌اند. اگر Caddy از نسخهٔ دقیق دیگری است یا خطا داد، توقف کنید؛ فایل‌های live را تغییر ندهید و log خام را ارسال نکنید.

## مرحلهٔ چهار — Payload واقعی روی محیط disposable (فقط پس از رفع blockerها و مجوز صریح)

این بخش فقط یک **برنامهٔ آتی** است و اکنون نباید اجرا شود. از checkout دقیق وبسایت استفاده کنید؛ فایل `compose.preview.yml` داخل بسته را برای build استفاده نکنید، چون build context باید خود checkout وبسایت باشد. overlay فعلی gate مصنوعی دارد، نه OAuth واقعی.

### A. کنترل project تازه و آماده‌سازی بی‌اثر بر داده

۱. مطمئن شوید checkout دقیق baseline و `compose.preview.yml` آن موجود است. پیش از شروع، فهرست project/volumeها را بخوانید؛ هیچ volume موجود را باز، reuse یا حذف نکنید:

```sh
docker compose ls --all
docker volume ls --filter label=com.docker.compose.project=xennic-preview-gate-payload-lab
```

اگر project/volume با این نام وجود دارد، توقف کنید؛ `down -v` یا پاک‌سازی انجام ندهید. DB باید تازه و مستقل باشد.

۲. پس از بررسی image digestها، Compose merge، port isolation و تأیید مالک، فایل env تصادفی فقط برای محیط disposable بسازید:

```sh
python3 /path/to/v1.1.1/prepare_payload_lab_env.py
```

این helper در `~/.config/xennic-preview-gate-delivery/payload-lab.env` مقادیر تصادفی را با mode `0600` می‌سازد و آن‌ها را چاپ نمی‌کند؛ اگر فایل از قبل هست، آن را overwrite نکنید. `.env.preview.example` فقط placeholder است و نباید source یا به Compose داده شود. `LAB_DIR` جداگانه باید مسیر مطلق پوشهٔ استخراج‌شدهٔ v1.1.1 باشد.

۳. در ریشهٔ checkout، ابتدا فقط Compose را بدون چاپ envها اعتبارسنجی کنید. خروجی `config` را بدون `--quiet` اجرا/ارسال نکنید:

```sh
BUNDLE=/absolute/path/to/xennic-preview-gate-delivery-2026-10-31-v1.1.1
ENV_FILE="$HOME/.config/xennic-preview-gate-delivery/payload-lab.env"
LAB_DIR="$BUNDLE" docker compose --env-file "$ENV_FILE" \
  -p xennic-preview-gate-payload-lab \
  -f compose.preview.yml -f "$BUNDLE/compose.payload-lab.override.yml" config --quiet
```

اگر Compose نسخهٔ لازم را ندارد، `!reset` parse نمی‌شود، `config --quiet` خطا می‌دهد، یا port/network مؤثر با انتظار فرق دارد، توقف کنید. حتی موفقیت این فرمان هنوز blockerهای runtime را رفع نمی‌کند.

۴. build فقط پس از تأیید provenance/digestها و مجوز:

```sh
LAB_DIR="$BUNDLE" docker compose --env-file "$ENV_FILE" \
  -p xennic-preview-gate-payload-lab \
  -f compose.preview.yml -f "$BUNDLE/compose.payload-lab.override.yml" build app
```

### B. ترتیب اجباری DB تازه: readiness → migration → verification → Staff bootstrap → seed

ترتیب زیر الزامی است. هر خطا یا خروجی نامنتظره به معنی **توقف کامل** است؛ migration ناموفق یا نامطمئن یعنی app، Staff bootstrap و seed را شروع نکنید.

۵. فقط PostgreSQL را start کنید و تا healthcheck `pg_isready` سالم نشود ادامه ندهید. `--wait` باید سرویس را تا healthy نگه دارد/منتظر بماند:

```sh
LAB_DIR="$BUNDLE" docker compose --env-file "$ENV_FILE" \
  -p xennic-preview-gate-payload-lab \
  -f compose.preview.yml -f "$BUNDLE/compose.payload-lab.override.yml" \
  up -d --wait postgres
```

۶. migration را صریحاً یک‌بار به‌صورت one-shot اجرا کنید؛ migration خودکار در startup انجام نمی‌شود:

```sh
LAB_DIR="$BUNDLE" docker compose --env-file "$ENV_FILE" \
  -p xennic-preview-gate-payload-lab \
  -f compose.preview.yml -f "$BUNDLE/compose.payload-lab.override.yml" \
  run --rm --no-deps app npm run preview:migrate
```

دستور باید exit code صفر بدهد و wrapper پیام `Preview migration completed.` چاپ کند. اگر دستور خطا داد، پیام عمومی خطاست، ledger غایب است، baseline ناقص است یا خروجی نامعلوم است: **توقف**؛ `app`, Staff bootstrap و seed را اجرا نکنید. خطاهای خام DB/connection string را به اشتراک نگذارید.

۷. پس از exit code صفر، DB را با query فقط‌خواندنی دوباره بررسی کنید. query باید دقیقاً `t` چاپ کند؛ `f`، خطا، خروجی اضافی یا خالی یعنی توقف:

```sh
MIGRATION_OK=$(LAB_DIR="$BUNDLE" docker compose --env-file "$ENV_FILE" \
  -p xennic-preview-gate-payload-lab \
  -f compose.preview.yml -f "$BUNDLE/compose.payload-lab.override.yml" \
  exec -T postgres sh -lc 'psql -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Atc "SELECT (to_regclass('\''website.payload_migrations'\'') IS NOT NULL AND to_regclass('\''shared.customers'\'') IS NOT NULL AND EXISTS (SELECT 1 FROM website.payload_migrations WHERE name = '\''20261030_163225_baseline'\'' AND batch >= 0) AND NOT EXISTS (SELECT 1 FROM website.payload_migrations WHERE batch = -1))::text;')
test "$MIGRATION_OK" = t || { echo 'Migration verification failed; stop before app, Staff, or seed.'; exit 1; }
```

این query فقط وجود migration ledger، ثبت baseline با batch غیرمنفی، نبود schema-push batch `-1` و وجود `shared.customers` را تأیید می‌کند؛ schema کامل/قابلیت restore را ثابت نمی‌کند. wrapper `preview:migrate` نیز به‌طور مستقل این baselineها را کنترل می‌کند.

۸. فقط اگر migration و query هر دو موفق‌اند، app و Caddy و **gate stub** را در همان project محدود شروع کنید. اجرای این فرمان به blockerهای بالا و مجوز جدید وابسته است:

```sh
LAB_DIR="$BUNDLE" docker compose --env-file "$ENV_FILE" \
  -p xennic-preview-gate-payload-lab \
  -f compose.preview.yml -f "$BUNDLE/compose.payload-lab.override.yml" \
  up -d --wait app caddy gate
```

Caddy روی `127.0.0.1:443` در نظر گرفته شده؛ app، Postgres و gate نباید host port داشته باشند. این رفتار هنوز با Compose merge یا `docker ps` runtime تأیید نشده است. اگر port mapping یا bind غیرمنتظره دیدید، آزمون را متوقف کنید. `gate_stub.py` احراز هویت یا identity نیست؛ هر process محلی می‌تواند marker مصنوعی را بفرستد. این مرحله فقط آزمایش disposable است، نه bootstrap امن حساب واقعی.

### C. یک‌بار Staff آزمایشی و آزمون API؛ سپس یک‌بار seed

۹. پس از سالم‌شدن app، CA عمومی Caddy را فقط به مسیر خصوصی محلی برای client آزمایش کپی کنید؛ private key را کپی نکنید:

```sh
CID=$(LAB_DIR="$BUNDLE" docker compose --env-file "$ENV_FILE" -p xennic-preview-gate-payload-lab \
  -f compose.preview.yml -f "$BUNDLE/compose.payload-lab.override.yml" ps -q caddy)
test -n "$CID" || { echo 'Caddy container not found; stop.'; exit 1; }
docker cp "$CID:/data/caddy/pki/authorities/local/root.crt" \
  "$HOME/.config/xennic-preview-gate-delivery/lab-root.crt"
```

۱۰. آزمون `test_payload_caddy.mjs` با `LAB_CA_FILE`، host mapping فقط در resolver همان Node process، gate marker مصنوعی و یک Staff تصادفی `example.invalid` اجرا شود:

```sh
LAB_CA_FILE="$HOME/.config/xennic-preview-gate-delivery/lab-root.crt" \
  node "$BUNDLE/test_payload_caddy.mjs"
```

این آزمون یک Staff مصنوعی را از first-register می‌سازد، logout می‌کند، Bearer قبلی را با انتظار درست `HTTP 200` و `user:null` می‌سنجد، برای آزمون‌های بعدی login تازه می‌گیرد، GraphQL را با/بدون gate می‌سنجد، سپس PNG تصادفی را با gate و Payload Staff می‌نویسد و metadata/bytes را با و بدون gate می‌خواند. هیچ حساب واقعی یا دادهٔ مشتری استفاده نشود. اگر پس از first-register آزمون شکست خورد، حساب bootstrap‌شده باقی می‌ماند؛ first-register را روی همان DB دوباره اجرا نکنید، DB/volume را پاک نکنید و seed را شروع نکنید. توقف و بررسی لازم است.

**مرز bootstrap امن:** مرحلهٔ بالا فقط Staff مصنوعی در lab loopback است؛ gate stub هویت یا امنیت واقعی ندارد و هر process محلی می‌تواند marker آن را جعل کند. از آن برای حساب واقعی/مالک استفاده نکنید. bootstrap واقعی خارج از این بسته است و تا وقتی gate واقعی بازبینی‌شده، حذف و آزمون عدم‌دسترسی پورت مستقیم app، مسیر local/tunnel مجاز، و تحویل credential از کانال امنِ مورد تأیید مالک تعیین نشده، نباید انجام شود. در آن فرایند credential واقعی هرگز در Git، log یا چت قرار نگیرد و first-register فقط یک بار روی DB تازه و حفاظت‌شده انجام شود.

۱۱. فقط اگر آزمون کامل موفق شد، seed سایت را **یک‌بار** در همان DB تازه اجرا کنید:

```sh
LAB_DIR="$BUNDLE" docker compose --env-file "$ENV_FILE" \
  -p xennic-preview-gate-payload-lab \
  -f compose.preview.yml -f "$BUNDLE/compose.payload-lab.override.yml" \
  run --rm --no-deps app npm run preview:seed
```

پیش‌شرط‌ها: migration query برابر `t`، baseline معتبر، Staff آزمایشی bootstrap شده و integration test موفق. wrapper advisory lock برای جلوگیری از اجرای هم‌زمان دارد و seed کدهای محتوایی موجود را overwrite نمی‌کند؛ با این حال ledger دائمی «seed انجام شد» ندارد. بنابراین پس از موفقیت دوباره اجرا نکنید. اگر seed exit غیرصفر داد، خودکار retry نکنید؛ محتوا/DB را بازبینی و تصمیم جدا بگیرید. این seed محتوای preview مصوب سایت است؛ writeهای خود integration test همچنان فقط Staff و فایل PNG مصنوعی هستند.

### D. توقف

پس از تست موفق، فقط project یکتای همین lab را بدون حذف volume متوقف کنید:

```sh
LAB_DIR="$BUNDLE" docker compose --env-file "$ENV_FILE" \
  -p xennic-preview-gate-payload-lab \
  -f compose.preview.yml -f "$BUNDLE/compose.payload-lab.override.yml" down
```

`down` بدون `-v` داده را نگه می‌دارد. `docker compose down -v`, `docker volume rm`, stop/restart سرویس‌های دیگر، تغییر پورت یا دست‌کاری داده‌های موجود مجاز نیست. در صورت عدم تطابق project، cleanup نکنید و از مالک سؤال کنید.

## مواردی که Runbook پوشش نمی‌دهد

- OAuth2 Proxy/GitHub واقعی یا egress واقعی gate به GitHub؛ overlay از stub مصنوعی و network `internal: true` استفاده می‌کند و egress به اینترنت ندارد.
- اثبات Compose مؤثر، عدم bypass از app port (شامل IPv6/host route) یا امن‌بودن publish نهایی؛ این‌ها blocker باز و نیازمند بازبینی و آزمون مجاز جدا هستند.
- تأیید registry provenance/digestها، DNS/TLS عمومی، VPS، firewall، backup/restore، ظرفیت بار یا recovery عملیاتی.
- bootstrap حساب Staff واقعی/مالک، ارسال ایمیل، OAuth scope نهایی، account دوم یا outage با نشست معتبر.

هیچ‌یک از این مراحل روی VPS، DNS، gate فعال، مالک یا service عملیاتی انجام نمی‌شود.
