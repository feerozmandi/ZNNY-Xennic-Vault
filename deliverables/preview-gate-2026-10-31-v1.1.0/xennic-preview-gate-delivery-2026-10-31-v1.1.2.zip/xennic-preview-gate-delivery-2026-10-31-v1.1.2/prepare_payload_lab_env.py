#!/usr/bin/env python3
"""Create synthetic Payload/Postgres credentials outside the bundle (never prints them)."""
import os
from pathlib import Path
import secrets

path = Path.home() / '.config' / 'xennic-preview-gate-delivery' / 'payload-lab.env'
path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
os.chmod(path.parent, 0o700)
if path.exists():
    raise SystemExit('Refusing to overwrite an existing private test env file.')
password = secrets.token_hex(32)
payload_secret = secrets.token_urlsafe(48)
text = '\n'.join([
    'PREVIEW_POSTGRES_DB=xennic_preview_lab',
    'PREVIEW_POSTGRES_USER=xennic_preview_lab',
    f'PREVIEW_POSTGRES_PASSWORD={password}',
    f'PREVIEW_DATABASE_URL=postgresql://xennic_preview_lab:{password}@postgres:5432/xennic_preview_lab',
    f'PREVIEW_PAYLOAD_SECRET={payload_secret}',
    'PREVIEW_ORIGIN=https://preview.xennic.ir',
    'PREVIEW_PORT=3000',
    '',
])
fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(fd, 'w') as stream:
    stream.write(text)
print('Created private synthetic-only env file outside this package (mode 0600). Its values were not printed.')
