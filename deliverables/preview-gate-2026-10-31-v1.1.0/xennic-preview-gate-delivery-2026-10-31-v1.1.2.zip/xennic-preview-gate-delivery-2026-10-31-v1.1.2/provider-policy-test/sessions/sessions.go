package sessions

type SessionState struct {
	AccessToken string
	Groups      []string
	Email       string
	User        string
}
