package policytest

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"

	"example.invalid/xennic-provider-policy-test/sessions"
)

func TestPinnedProviderPolicy(t *testing.T) {
	cases := []struct {
		name string
		login string
		failPath string
		failCall int
		wantError string
		wantUserCalls int
		malformed bool
	}{
		{name:"allowed owner profile", login:"feerozmandi", wantUserCalls:2},
		{name:"distinct non-owner profile successfully fetched then denied by allowlist", login:"synthetic-other", wantError:"missing github user", wantUserCalls:1},
		{name:"empty profile is ambiguous with missing-user error", wantError:"missing github user", wantUserCalls:1},
		{name:"organization scope API 403 precedes profile lookup", login:"synthetic-other", failPath:"/user/orgs", wantError:"unexpected status 403"},
		{name:"team scope API 403 precedes profile lookup", login:"synthetic-other", failPath:"/user/teams", wantError:"unexpected status 403"},
		{name:"profile fetch 403 before allowlist check", login:"synthetic-other", failPath:"/user", failCall:1, wantError:"unexpected status 403", wantUserCalls:1},
		{name:"profile fetch 403 after allowlist check", login:"feerozmandi", failPath:"/user", failCall:2, wantError:"unexpected status 403", wantUserCalls:2},
		{name:"malformed profile is a decode error", login:"synthetic-other", wantError:"invalid character", wantUserCalls:1, malformed:true},
		{name:"email API 403 after owner allowlist succeeds", login:"feerozmandi", failPath:"/user/emails", wantError:"unexpected status 403", wantUserCalls:1},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			userCalls := 0
			profileLogins := []string{}
			srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				if r.Header.Get("Authorization") != "token synthetic" {
					t.Error("missing synthetic auth")
					w.WriteHeader(http.StatusUnauthorized)
					return
				}
				if r.URL.Path == "/user" { userCalls++ }
				if r.URL.Path == tc.failPath && (tc.failCall == 0 || (r.URL.Path == "/user" && userCalls == tc.failCall)) {
					w.WriteHeader(http.StatusForbidden)
					fmt.Fprint(w, `{}`)
					return
				}
				switch r.URL.Path {
				case "/user/orgs", "/user/teams": fmt.Fprint(w, `[]`)
				case "/user":
					if tc.malformed { fmt.Fprint(w, `not-json`); return }
					profileLogins = append(profileLogins, tc.login)
					fmt.Fprintf(w, `{"login":%q}`, tc.login)
				case "/user/emails": fmt.Fprint(w, `[{"email":"synthetic@example.invalid","primary":true,"verified":true}]`)
				default: t.Errorf("unexpected endpoint %s", r.URL.Path); w.WriteHeader(http.StatusNotFound)
				}
			}))
			defer srv.Close()
			base, _ := url.Parse(srv.URL)
			p := &GitHubProvider{Users:[]string{"feerozmandi"}, base:base}
			session := &sessions.SessionState{AccessToken:"synthetic"}
			err := p.EnrichSession(context.Background(), session)
			if tc.wantError == "" {
				if err != nil || session.User != "feerozmandi" { t.Fatalf("expected owner, got err=%v", err) }
			} else if err == nil || !strings.Contains(err.Error(), tc.wantError) {
				t.Fatalf("want error containing %q, got %v", tc.wantError, err)
			}
			if userCalls != tc.wantUserCalls { t.Fatalf("want %d profile calls, got %d", tc.wantUserCalls, userCalls) }
			if strings.HasPrefix(tc.name, "distinct non-owner") &&
				(len(profileLogins) != 1 || profileLogins[0] != "synthetic-other" || err == nil || err.Error() != "missing github user") {
				t.Fatalf("allowlist decision must follow successful non-owner profile; got logins=%v error=%v", profileLogins, err)
			}
			if strings.HasPrefix(tc.name, "empty profile") && len(profileLogins) != 1 {
				t.Fatalf("expected a successfully fetched empty profile, got %d calls", len(profileLogins))
			}
		})
	}
}
