// Test-only replacement for OAuth2 Proxy HTTP/session/config plumbing.
// The allowlist/provider methods in provider_extracted.go remain source-identical.
package policytest

import (
	"context"
	"errors"
	"net/http"
	"net/url"

	"example.invalid/xennic-provider-policy-test/sessions"
)

type GitHubProvider struct {
	Users []string
	Org, Team, Repo, Token string
	base *url.URL
}

const orgTeamSeparator = ":"
var logger = struct{ Printf func(string, ...any) }{Printf: func(string, ...any) {}}

func makeGitHubHeader(token string) http.Header {
	return http.Header{"Authorization": []string{"token " + token}}
}
func (p *GitHubProvider) makeGitHubAPIEndpoint(endpoint string, params *url.Values) *url.URL {
	u := *p.base
	u.Path = endpoint
	if params != nil { u.RawQuery = params.Encode() }
	return &u
}
func (*GitHubProvider) hasOrg(*sessions.SessionState) error { return errors.New("unexpected org policy") }
func (*GitHubProvider) hasTeam(*sessions.SessionState) error { return errors.New("unexpected team policy") }
func (*GitHubProvider) hasOrgAndTeam(*sessions.SessionState) error { return errors.New("unexpected org/team policy") }
func (*GitHubProvider) hasRepoAccess(context.Context, string) error { return errors.New("unexpected repo policy") }
func (*GitHubProvider) isCollaborator(context.Context, string, string) (bool, error) {
	return false, errors.New("unexpected collaborator policy")
}
