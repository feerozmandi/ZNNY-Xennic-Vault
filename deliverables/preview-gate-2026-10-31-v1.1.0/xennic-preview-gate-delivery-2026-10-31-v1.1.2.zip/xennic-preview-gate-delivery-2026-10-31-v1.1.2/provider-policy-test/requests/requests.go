// Test double for only the JSON GETs used by the extracted provider methods.
// This is not oauth2-proxy's production requests package.
package requests

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
)

type request struct {
	url     string
	ctx     context.Context
	headers http.Header
}
type result struct {
	resp *http.Response
	err  error
}

func New(url string) *request { return &request{url: url} }
func (r *request) WithContext(ctx context.Context) *request { r.ctx = ctx; return r }
func (r *request) WithHeaders(h http.Header) *request { r.headers = h; return r }
func (r *request) Do() *result {
	req, err := http.NewRequestWithContext(r.ctx, http.MethodGet, r.url, nil)
	if err != nil { return &result{err: err} }
	req.Header = r.headers
	resp, err := http.DefaultClient.Do(req)
	return &result{resp: resp, err: err}
}
func (r *result) UnmarshalInto(dst any) error {
	if r.err != nil { return r.err }
	defer r.resp.Body.Close()
	if r.resp.StatusCode != http.StatusOK { return fmt.Errorf("unexpected status %d", r.resp.StatusCode) }
	return json.NewDecoder(r.resp.Body).Decode(dst)
}
