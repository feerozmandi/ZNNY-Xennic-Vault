module example.invalid/xennic-provider-policy-test

go 1.23
