#!/usr/bin/env python3
"""Extract unchanged v7.15.5 GitHub-provider methods; validates pinned source SHA256."""
import hashlib
from pathlib import Path
import re

BASE = Path(__file__).resolve().parent
source = (BASE / 'testdata/github.v7.15.5.go.txt').read_bytes()
expected = '03aee25d95c40af66cdbe932eca288f594621c2ee40696ce88b03be45cfa075e'
if hashlib.sha256(source).hexdigest() != expected:
    raise SystemExit('Pinned provider source hash mismatch; stop.')
text = source.decode()
methods = ['EnrichSession','getOrgAndTeam','getOrgs','getTeams','checkRestrictions',
           'checkUserRestriction','hasUser','isVerifiedUser','getEmail','getUser']
chunks = []
for name in methods:
    match = re.search(r'^func \(p \*GitHubProvider\) ' + name + r'\(', text, re.M)
    if not match: raise SystemExit('Missing expected method: ' + name)
    end = re.search(r'^}\s*$', text[match.start():], re.M)
    if not end: raise SystemExit('Unterminated method: ' + name)
    chunks.append(text[match.start():match.start()+end.end()].rstrip())
header = '''// Generated from unchanged OAuth2 Proxy v7.15.5 provider methods.
// Network/session interfaces are test doubles; this is not the OAuth2 Proxy binary.
package policytest
import (
    "context"
    "errors"
    "fmt"
    "net/url"
    "strconv"
    "example.invalid/xennic-provider-policy-test/requests"
    "example.invalid/xennic-provider-policy-test/sessions"
)
'''
(BASE / 'provider_extracted.go').write_text(header + '\n\n'.join(chunks) + '\n')
print('PASS source SHA256 and pinned methods extracted')
