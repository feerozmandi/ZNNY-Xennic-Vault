// Generated from unchanged OAuth2 Proxy v7.15.5 provider methods.
// Network/session interfaces are test doubles; this is not the OAuth2 Proxy binary.
package policytest
import (
    "context"
    "errors"
    "fmt"
    "net/url"
    "strconv"
    "example.invalid/xennic-provider-policy-test/requests"
    "example.invalid/xennic-provider-policy-test/sessions"
)
func (p *GitHubProvider) EnrichSession(ctx context.Context, s *sessions.SessionState) error {
	// Construct user info JSON from multiple GitHub API endpoints to have a more detailed session state
	if err := p.getOrgAndTeam(ctx, s); err != nil {
		return err
	}

	if err := p.checkRestrictions(ctx, s); err != nil {
		return err
	}

	if err := p.getEmail(ctx, s); err != nil {
		return err
	}

	return p.getUser(ctx, s)
}

func (p *GitHubProvider) getOrgAndTeam(ctx context.Context, s *sessions.SessionState) error {
	err := p.getOrgs(ctx, s)
	if err != nil {
		return err
	}

	return p.getTeams(ctx, s)
}

func (p *GitHubProvider) getOrgs(ctx context.Context, s *sessions.SessionState) error {

	type Organization struct {
		// Support for Github organizations
		// https://docs.github.com/en/rest/orgs/orgs#list-organizations-for-the-authenticated-user
		Login string `json:"login,omitempty"`
		// Support for Gitea organizations
		// https://docs.gitea.com/api/1.24/#tag/organization/operation/orgGetAll
		Name string `json:"name,omitempty"`
	}

	pn := 1
	for {
		params := url.Values{
			"per_page": {"100"},
			"page":     {strconv.Itoa(pn)},
		}

		endpoint := p.makeGitHubAPIEndpoint("/user/orgs", &params)

		var orgs []Organization
		err := requests.New(endpoint.String()).
			WithContext(ctx).
			WithHeaders(makeGitHubHeader(s.AccessToken)).
			Do().
			UnmarshalInto(&orgs)
		if err != nil {
			return err
		}

		if len(orgs) == 0 {
			break
		}

		for _, org := range orgs {
			var orgName string
			if len(org.Login) > 0 {
				orgName = org.Login
				logger.Printf("Member of Github Organization: %q", orgName)
			} else {
				orgName = org.Name
				logger.Printf("Member of Gitea Organization: %q", orgName)
			}

			s.Groups = append(s.Groups, orgName)
		}
		pn++
	}

	return nil
}

func (p *GitHubProvider) getTeams(ctx context.Context, s *sessions.SessionState) error {
	// https://docs.github.com/en/rest/teams/teams?#list-user-teams
	type Team struct {
		Name string `json:"name"`
		Slug string `json:"slug"`
		Org  struct {
			Login string `json:"login"`
			Name  string `json:"name"`
		} `json:"organization"`
	}

	pn := 1
	for {
		params := url.Values{
			"per_page": {"100"},
			"page":     {strconv.Itoa(pn)},
		}

		endpoint := p.makeGitHubAPIEndpoint("/user/teams", &params)

		var teams []Team
		err := requests.New(endpoint.String()).
			WithContext(ctx).
			WithHeaders(makeGitHubHeader(s.AccessToken)).
			Do().
			UnmarshalInto(&teams)
		if err != nil {
			return err
		}

		if len(teams) == 0 {
			break
		}

		for _, team := range teams {
			var orgName, teamName string

			if len(team.Org.Login) > 0 {
				orgName = team.Org.Login
				teamName = team.Slug
				logger.Printf("Member of Github Organization/Team: %q/%q", orgName, teamName)
			} else {
				orgName = team.Org.Name
				teamName = team.Name
				logger.Printf("Member of Gitea Organization/Team: %q/%q", orgName, teamName)
			}

			s.Groups = append(s.Groups, fmt.Sprintf("%s%s%s", orgName, orgTeamSeparator, teamName))
		}

		pn++
	}

	return nil
}

func (p *GitHubProvider) checkRestrictions(ctx context.Context, s *sessions.SessionState) error {
	// If a user is verified by username options, skip the following restrictions
	if ok, err := p.checkUserRestriction(ctx, s); err != nil || ok {
		return err
	}

	var err error
	switch {
	case p.Org != "" && p.Team != "":
		err = p.hasOrgAndTeam(s)
	case p.Org != "":
		err = p.hasOrg(s)
	case p.Team != "":
		err = p.hasTeam(s)
	}

	if err != nil {
		return err
	}

	if p.Org == "" && p.Repo != "" && p.Token == "" {
		// If we have a token we'll do the collaborator check
		return p.hasRepoAccess(ctx, s.AccessToken)
	}

	return nil
}

func (p *GitHubProvider) checkUserRestriction(ctx context.Context, s *sessions.SessionState) (bool, error) {
	if len(p.Users) == 0 {
		return false, nil
	}

	verifiedUser, err := p.hasUser(ctx, s.AccessToken)
	if err != nil {
		return verifiedUser, err
	}

	// org and repository options are not configured
	if !verifiedUser && p.Org == "" && p.Repo == "" {
		return false, errors.New("missing github user")
	}

	return verifiedUser, nil
}

func (p *GitHubProvider) hasUser(ctx context.Context, accessToken string) (bool, error) {
	// https://developer.github.com/v3/users/#get-the-authenticated-user

	var user struct {
		Login string `json:"login"`
		Email string `json:"email"`
	}

	endpoint := p.makeGitHubAPIEndpoint("/user", nil)

	err := requests.New(endpoint.String()).
		WithContext(ctx).
		WithHeaders(makeGitHubHeader(accessToken)).
		Do().
		UnmarshalInto(&user)
	if err != nil {
		return false, err
	}

	if p.isVerifiedUser(user.Login) {
		return true, nil
	}
	return false, nil
}

func (p *GitHubProvider) isVerifiedUser(username string) bool {
	for _, u := range p.Users {
		if username == u {
			return true
		}
	}
	return false
}

func (p *GitHubProvider) getEmail(ctx context.Context, s *sessions.SessionState) error {

	var emails []struct {
		Email    string `json:"email"`
		Primary  bool   `json:"primary"`
		Verified bool   `json:"verified"`
	}

	endpoint := p.makeGitHubAPIEndpoint("/user/emails", nil)

	err := requests.New(endpoint.String()).
		WithContext(ctx).
		WithHeaders(makeGitHubHeader(s.AccessToken)).
		Do().
		UnmarshalInto(&emails)
	if err != nil {
		return err
	}

	for _, email := range emails {
		if email.Verified {
			if email.Primary {
				s.Email = email.Email
				return nil
			}
		}
	}

	return nil
}

func (p *GitHubProvider) getUser(ctx context.Context, s *sessions.SessionState) error {
	var user struct {
		Login string `json:"login"`
		Email string `json:"email"`
	}

	endpoint := p.makeGitHubAPIEndpoint("/user", nil)

	err := requests.New(endpoint.String()).
		WithContext(ctx).
		WithHeaders(makeGitHubHeader(s.AccessToken)).
		Do().
		UnmarshalInto(&user)
	if err != nil {
		return err
	}

	// Now that we have the username we can check collaborator status
	if !p.isVerifiedUser(user.Login) && p.Org == "" && p.Repo != "" && p.Token != "" {
		if ok, err := p.isCollaborator(ctx, user.Login, p.Token); err != nil || !ok {
			return err
		}
	}

	s.User = user.Login
	return nil
}
