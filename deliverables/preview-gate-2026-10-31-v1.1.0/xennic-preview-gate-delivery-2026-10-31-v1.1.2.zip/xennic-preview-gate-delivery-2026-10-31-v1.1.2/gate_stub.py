#!/usr/bin/env python3
"""Synthetic test gate only; not OAuth, identity, or access control."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

COOKIE = '__Host-preview_gate=synthetic-owner'

class GateStub(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_GET(self):
        if self.path.startswith('/oauth2/auth'):
            authorized = any(
                part.strip() == COOKIE
                for value in self.headers.get_all('Cookie', [])
                for part in value.split(';')
            )
            self.send_response(202 if authorized else 401)
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            return
        if self.path.startswith('/oauth2/'):
            self.send_response(403)
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            self.wfile.write(b'Synthetic test gate only; OAuth is not implemented.')
            return
        self.send_response(404)
        self.end_headers()

ThreadingHTTPServer(('0.0.0.0', 4180), GateStub).serve_forever()
