# وضعیت اعتبارسنجی بستهٔ `1.1.2`

**هیچ package test، endpoint runtime، stack یا migration/seed در تهیهٔ این نسخه اجرا نشده است.** `test_caddy_mock.py` و `test_payload_caddy.mjs` فقط اصلاح شده‌اند؛ اجرای آن‌ها پیش از review/approval ممنوع است. Caddy، Docker Compose stack، Payload/Postgres، OAuth/GitHub، browser، VPS، DNS و gate فعال راه‌اندازی/تغییر نشده‌اند. `verify_bundle.py` و سایر package scripts نیز در این turn اجرا نشده‌اند.

## بازبینی source-level (نه آزمون)

یافته‌های Payload `3.91.0` حفظ شده‌اند: `useSessions` به‌طور پیش‌فرض فعال است؛ logout همان `sid` را حذف می‌کند؛ JWT strategy session فعال را می‌خواهد؛ و `/api/staff/me` برای token لغوشده HTTP 200 با `user:null` می‌دهد. این source review است، نه اجرای endpoint. Migration query یا Payload media API اجرا نشده است.

## بررسی‌های ایستای انجام‌شده

- Python syntax با `compile()` در حافظه برای ۸ فایل؛ هیچ ماژولی اجرا نشد.
- `node --check` برای ۳ فایل JS/MJS؛ اسکریپت‌ها اجرا نشدند.
- `bash -n` برای ۱۷ بلوک shell در Runbook؛ فرمان‌ها اجرا نشدند.
- PNG fixture به‌صورت ایستا: ۷۰ بایت، 1x1 RGBA، IHDR/IDAT/IEND، CRC همهٔ chunkها و zlib stream معتبر.
- `MANIFEST.json`/`SHA256SUMS` بازتولید و با hash فایل‌های package مقایسه شدند؛ bundled verifier اجرا نشده است.
- ZIP/TXT/sidecar پس از بسته‌بندی: ZIP integrity، برابری byte-for-byte تمام ۴۰ ورودی ZIP با source و تطبیق byte/hash تمام ۴۰ رکورد TXT کنترل شد.

این‌ها فقط syntax و integrity/content را می‌سنجند؛ رفتار route، migration، auth، media یا Compose را ثابت نمی‌کنند.

## آزمون‌ها و blockerهای اجرا‌نشده

- `test_caddy_mock.py`, `check_caddy_config.py`, `test_payload_caddy.mjs` — اجرا نشده‌اند.
- Compose merge/config/build/up, direct port exposure, network egress, volume/health behavior — اجرا نشده‌اند.
- `preview:migrate`, SQL verification، first-register Staff bootstrap، `preview:seed` — اجرا نشده‌اند.
- OAuth/GitHub واقعی، account دوم، media upload/bytes، GraphQL server، browser/CA، DNS/TLS، VPS، backup/restore، load و gate فعال — اجرا نشده‌اند.
- Caddy/Python image digestها independently verify نشده‌اند؛ Node/Postgres tag-only هستند.

**عدم ادعا:** static fix، source review، syntax check یا checksum مساوی PASS runtime یا پذیرش برای آزمون isolated نیست. Compose/effective ports، digest provenance و egress GitHub همچنان blocker هستند.
