# بستهٔ موردنیاز دستیار وبسایت برای بازبینی — نسخهٔ 1.1.2

مبنای دقیق: `feerozmandi/xennic-website@418de2b5b3a272e79a824ccde5411dc25f1002cc`. بسته شامل ۴۰ فایل غیرمحرمانه است. **درخواست: بازبینی ایستا فقط؛ هیچ اسکریپت بسته، stack، migration، seed، OAuth/GitHub، browser، VPS، DNS یا gate فعال اجرا نشود.** نسخه‌های 1.1.1 و 1.1.0 superseded/DO NOT RUN هستند؛ فقط 1.1.2 را بازبینی کنید.

## اولویت ۱ — migration check و DB ترتیب

- `RUNBOOK.fa.md` — در psql query، `::text` حذف شده؛ `SELECT boolean` با `-At` باید `t/f` بدهد و شرط shell با `t` هماهنگ است. لطفاً فقط از نظر SQL/psql و quoting ایستا بازبینی کنید؛ query اجرا نشده.
- `scripts/preview-task.mjs`, `migrations/index.ts`, `migrations/20261030_163225_baseline.ts`, `scripts/seed.ts` در checkout baseline — lock، migration ledger، `shared.customers`, batch `-1`, one-shot seed و preconditions را مقایسه کنید. Seed ledger دائمی ندارد؛ اجرای یک‌باره operator-enforced است.

## اولویت ۲ — Payload media form/route

- `test_payload_caddy.mjs` — multipart اکنون `_payload` JSON با `alt`، فایل `file` با PNG مصنوعی معتبر، و مسیر `/api/media/file/...` را به‌کار می‌برد. بازیابی metadata و bytes، و denial بدون gate، هر دو در کد تست هستند؛ اجرا نشده‌اند.
- PNG fixture — بررسی byte/chunk/CRC/zlib ایستا شده؛ لطفاً format و Payload upload contract را با نسخهٔ دقیق baseline بازبینی کنید.
- `test_caddy_mock.py` — endpoint `/api/media/file/synthetic.png` بدون gate باید 401 بگیرد؛ mock test اجرا نشده است.
- endpoint ایجاد/بازیابی رسانه در Payload baseline و URL تولیدشده از `PREVIEW_ORIGIN` را با source دقیق تطبیق دهید؛ هیچ پاسخ status runtime فرض نشده است.

## اولویت ۳ — اصلاحات حفظ‌شده از v1.1.1

- Payload `3.91.0` logout/Bearer: `sid` لغوشده، `/api/staff/me` با انتظار `HTTP 200` و `user:null`، و login تازه برای درخواست‌های بعدی.
- Cookie mock: موفقیت gate، upstream reach و حذف Cookie gate پس از filter.
- `/api/graphql` با gate و بدون آن.
- تمام writeهای integration test فقط random Staff از `example.invalid` و PNG مصنوعی هستند.

## اولویت ۴ — blockerهای runtime هنوز باز

لطفاً هر مورد را «تأیید»، «نیازمند اصلاح» یا «نامعلوم» علامت بزنید:

1. آیا Compose merge در نسخهٔ موردنیاز به‌طور واقعی پورت مستقیم app را حذف می‌کند؟ آیا bypass در IPv4/IPv6 یا host routing باقی می‌ماند؟
2. آیا gate واقعی باید به GitHub egress داشته باشد و چه allowlistی لازم است؟ overlay فعلی gate stub و network `internal: true` دارد و هیچ OAuth/GitHub egress واقعی را نمی‌آزماید.
3. آیا image digestهای Caddy/Python از registry و platform درست‌اند؟ Node/Postgres digest pin ندارند.
4. آیا `_payload` + `file` دقیقاً form contract نسخهٔ Payload `3.91.0` است و upload response مسیر `/api/media/file/{filename}` می‌دهد؟ لطفاً فقط با source/pinned docs تطبیق دهید؛ endpoint اجرا نشود.
5. آیا query migration خام boolean در psql `-At` مطابق `t/f` چاپ می‌کند؟ query اجرا نشده است؛ اگر جایگزین مطمئن‌تری لازم است، گزارش کنید.
6. آیا source-level logout/session finding و HTTP `200 user:null` برای همین نسخهٔ Payload معتبر است؟ Token `401` فرض نشود.

## فایل‌های اصلاح‌شده در 1.1.2

`README.fa.md`, `CHANGELOG.fa.md`, `RUNBOOK.fa.md`, `FILES-FOR-WEBSITE-ASSISTANT.fa.md`, `REVIEW-REPORT.fa.md`, `VALIDATION.fa.md`, `VERSIONS-DIGESTS.fa.md`, `test_caddy_mock.py`, `test_payload_caddy.mjs`, `MANIFEST.json`, `SHA256SUMS`.

## محدودیت بازبینی

- هیچ فایل config روی gate فعال apply/reload نشود.
- Compose، Caddy، Payload/Postgres، migration/seed، OAuth/GitHub، DNS، VPS یا stack اجرا نشود.
- digest review و مالکیت OAuth App را از hash source یا tag image استنتاج نکنید.
- Open Notebook، Hermes و `[RAG-02]` خارج از دامنه هستند.
