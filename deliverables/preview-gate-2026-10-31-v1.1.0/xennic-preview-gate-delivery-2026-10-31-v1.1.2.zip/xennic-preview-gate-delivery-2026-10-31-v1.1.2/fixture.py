#!/usr/bin/env python3
"""Synthetic upstream only. No Payload code or real credentials are used/logged."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json

class Fixture(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_GET(self):
        auth = self.headers.get('Authorization', '')
        cookie = '; '.join(self.headers.get_all('Cookie', []))
        names = [item.strip().partition('=')[0] for item in cookie.split(';')]
        result = {
            'fixture': True,
            'bearer_preserved': auth == 'Bearer synthetic-payload-token',
            'payload_cookie_preserved': any(item.strip() == 'payload_test=synthetic' for item in cookie.split(';')),
            'gate_cookie_absent': not any(
                name == '__Host-preview_gate' or
                (name.startswith('__Host-preview_gate_') and name[len('__Host-preview_gate_'):].isdigit())
                for name in names
            ),
            'spoofed_identity_removed': not any(self.headers.get(h) for h in (
                'X-Forwarded-User', 'X-Forwarded-Email', 'X-Auth-Request-User',
                'X-Auth-Request-Email', 'Forwarded')),
        }
        data = json.dumps(result).encode()
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

ThreadingHTTPServer(('0.0.0.0', 3000), Fixture).serve_forever()
