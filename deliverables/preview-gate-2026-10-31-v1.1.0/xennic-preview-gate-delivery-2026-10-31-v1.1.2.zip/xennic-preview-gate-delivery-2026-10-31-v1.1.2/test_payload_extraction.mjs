// Uses the real extractJWT code from the exact Payload package installed by the
// website at commit 418de2b5. Synthetic headers only; not a full Payload server.
import assert from 'node:assert/strict'
import { pathToFileURL } from 'node:url'
import { resolve } from 'node:path'
import { readFile } from 'node:fs/promises'

const root = process.env.PAYLOAD_PACKAGE_DIR
assert(root, 'PAYLOAD_PACKAGE_DIR must point to the tested Payload package directory')
const pkg = JSON.parse(await readFile(resolve(root, 'package.json'), 'utf8'))
assert.equal(pkg.version, '3.91.0', 'Refusing to test an unexpected Payload version')
const { extractJWT } = await import(pathToFileURL(resolve(root, 'dist/auth/extractJWT.js')))
let raw = ''
for await (const chunk of process.stdin) raw += chunk
const cases = JSON.parse(raw)
for (const test of cases) {
  const headers = new Headers({Cookie:test.cookie, Authorization:'Bearer synthetic-payload', Origin:'https://preview.xennic.ir'})
  const payload = {config:{cookiePrefix:'payload', csrf:['https://preview.xennic.ir'], auth:{jwtOrder:['cookie']}}}
  assert.equal(extractJWT({headers,payload}), 'synthetic')
  payload.config.auth.jwtOrder = ['Bearer']
  assert.equal(extractJWT({headers,payload}), 'synthetic-payload')
}
console.log(`PASS actual Payload ${pkg.version} extractJWT: ${cases.length} cookie layouts and Bearer`)
