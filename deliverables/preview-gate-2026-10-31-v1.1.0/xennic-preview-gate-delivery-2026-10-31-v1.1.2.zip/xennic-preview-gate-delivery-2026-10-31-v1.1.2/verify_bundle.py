#!/usr/bin/env python3
"""Static non-secret/integrity check for this review bundle; starts no services."""
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parent
REQUIRED = {
    'README.fa.md','REVIEW-REPORT.fa.md','RUNBOOK.fa.md','FILES-FOR-WEBSITE-ASSISTANT.fa.md',
    'VERSIONS-DIGESTS.fa.md','CHANGELOG.fa.md','VALIDATION.fa.md',
    'Caddyfile','Caddyfile.lab','Caddyfile.payload.lab','routes.caddy','oauth-gateway.caddy','upstream.caddy',
    'compose.oauth-lab.reference.yml','compose.payload-lab.override.yml',
    'oauth2-proxy.example.toml','oauth2-proxy.lab.example.toml',
    'fixture.py','gate_stub.py','prepare_lab_config.py','prepare_payload_lab_env.py',
    'check_caddy_config.py','test_caddy_mock.py','test_payload_extraction.mjs','test_payload_caddy.mjs','test_payload_browser.js',
    'provider-policy-test/go.mod','provider-policy-test/generate.py','provider-policy-test/provider_extracted.go',
    'provider-policy-test/harness.go','provider-policy-test/provider_test.go',
    'provider-policy-test/requests/requests.go','provider-policy-test/sessions/sessions.go',
    'provider-policy-test/testdata/github.v7.15.5.go.txt','provider-policy-test/testdata/LICENSE.oauth2-proxy',
    'compose.preview.yml','.env.preview.example',
    'verify_bundle.py','MANIFEST.json','SHA256SUMS',
}
BAD_SUFFIXES = {'.pem','.key','.p12','.pfx','.env'}
BAD_NAMES = {'.env','oauth2.toml','credentials.json','cookies.txt','secrets.json'}
PRIVATE_KEY = re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----')
GH_TOKEN = re.compile(rb'\bgh[oprsu]_[A-Za-z0-9_]{30,}\b')
SECRET_ASSIGNMENT = re.compile(rb'(?im)^\s*(?:client_secret|cookie_secret)\s*=\s*["\'](?!REPLACE_IN_PRIVATE_FILE|REPLACE_WITH|UNAPPROVED)[^"\']{8,}["\']')


def fail(message):
    print('FAIL:', message, file=sys.stderr)
    raise SystemExit(1)


def main():
    actual = set()
    for path in ROOT.rglob('*'):
        if path.is_dir():
            if path.name in {'.git','node_modules','__pycache__'}:
                fail(f'forbidden generated/private directory: {path.relative_to(ROOT)}')
            continue
        if path.is_symlink() or not path.is_file():
            fail(f'non-regular or symlinked entry: {path.relative_to(ROOT)}')
        rel = path.relative_to(ROOT).as_posix()
        actual.add(rel)
        if path.name in BAD_NAMES or path.suffix.lower() in BAD_SUFFIXES:
            fail(f'private/credential-like file is not allowed: {rel}')
        data = path.read_bytes()
        # This scanner necessarily contains its own private-key detection regex.
        if rel != 'verify_bundle.py' and (PRIVATE_KEY.search(data) or GH_TOKEN.search(data) or SECRET_ASSIGNMENT.search(data)):
            fail(f'credential-shaped content found: {rel}')
    if actual != REQUIRED:
        fail('unexpected/missing files; unexpected=' + repr(sorted(actual-REQUIRED)) + ' missing=' + repr(sorted(REQUIRED-actual)))

    # Guardrails for the two Compose references.
    payload_override=(ROOT/'compose.payload-lab.override.yml').read_text()
    if '127.0.0.1:443:443/tcp' not in payload_override or 'ports: !reset []' not in payload_override:
        fail('Payload overlay is missing loopback-only Caddy or app-port reset guard')
    if re.search(r'(?m)^\s*-\s*["\']?0\.0\.0\.0:', payload_override):
        fail('Payload overlay contains a public bind')
    if 'preview_gate_lab:' not in payload_override or 'internal: true' not in payload_override:
        fail('Payload overlay lacks its project-scoped internal network')
    if payload_override.count('networks: [preview_gate_lab]') != 4:
        fail('all four Payload-lab services must use the isolated network')
    sample=(ROOT/'.env.preview.example').read_text()
    for line in sample.splitlines():
        if not line or line.lstrip().startswith('#'):
            continue
        if '=' not in line or not re.search(r'<[^>]+>', line.split('=',1)[1]):
            fail('environment sample contains a non-placeholder value')
    oauth=(ROOT/'compose.oauth-lab.reference.yml').read_text()
    if 'DO NOT RUN' not in oauth or '127.0.0.1:18443:443/tcp' not in oauth:
        fail('legacy OAuth Compose reference is not clearly marked unsafe/loopback')
    final_toml=(ROOT/'oauth2-proxy.example.toml').read_text()
    if 'scope = "UNAPPROVED_DO_NOT_RUN"' not in final_toml:
        fail('final OAuth template must remain explicitly unapproved')

    manifest_path=ROOT/'MANIFEST.json'
    manifest=json.loads(manifest_path.read_text())
    listed={entry['path']:entry for entry in manifest['files']}
    expected=set(actual)-{'MANIFEST.json','SHA256SUMS'}
    if set(listed)!=expected:
        fail('MANIFEST.json file set differs from current payload files')
    for rel,entry in listed.items():
        data=(ROOT/rel).read_bytes()
        if len(data)!=entry['size'] or hashlib.sha256(data).hexdigest()!=entry['sha256']:
            fail(f'manifest mismatch: {rel}')
    sums={}
    for line in (ROOT/'SHA256SUMS').read_text().splitlines():
        digest,rel=line.split('  ',1)
        sums[rel]=digest
    if set(sums)!=actual-{'SHA256SUMS'}:
        fail('SHA256SUMS file set differs from package')
    for rel,digest in sums.items():
        if hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()!=digest:
            fail(f'SHA256SUMS mismatch: {rel}')
    print(f'PASS bundle structure, placeholder-only secret checks, guardrails, manifest and {len(sums)} SHA256 entries')
    print('LIMITATION: this script does not validate Caddy/Compose/Go syntax, OCI image provenance, or deployment safety.')

if __name__=='__main__':
    main()
