#!/usr/bin/env python3
"""Create a private local OAuth2 Proxy config. Never prints or stores input secrets here."""
import base64
import getpass
import json
import os
from pathlib import Path
import re
import secrets

BASE = Path(__file__).resolve().parent
PRIVATE_DIR = Path.home() / '.config' / 'xennic-preview-gate-lab'
PRIVATE_PATH = PRIVATE_DIR / 'oauth2.toml'

PRIVATE_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)
os.chmod(PRIVATE_DIR, 0o700)
if PRIVATE_PATH.exists():
    raise SystemExit('Private config already exists; refusing to overwrite it.')

username = input('Allowed local-lab GitHub username: ').strip()
if username != 'feerozmandi' or not re.fullmatch(r'[A-Za-z0-9](?:[A-Za-z0-9-]{0,37}[A-Za-z0-9])?', username):
    raise SystemExit('This lab is restricted to the owner-approved account feerozmandi.')
print('LOCAL LAB ONLY: this config requests user:email and read:org; this is not production approval.')
if input('Type YES to confirm this local-only permission: ').strip() != 'YES':
    raise SystemExit('Stopped; no config was written.')
client_id = getpass.getpass('Local OAuth Client ID (hidden): ').strip()
client_secret = getpass.getpass('Local OAuth Client Secret (hidden): ').strip()
if not client_id or not client_secret:
    raise SystemExit('Both OAuth fields are required.')
cookie_secret = base64.urlsafe_b64encode(secrets.token_bytes(32)).decode()
text = (BASE / 'oauth2-proxy.lab.example.toml').read_text()
text = text.replace('client_id = "REPLACE_IN_PRIVATE_FILE"', 'client_id = ' + json.dumps(client_id))
text = text.replace('client_secret = "REPLACE_IN_PRIVATE_FILE"', 'client_secret = ' + json.dumps(client_secret))
text = text.replace('cookie_secret = "REPLACE_IN_PRIVATE_FILE"', 'cookie_secret = ' + json.dumps(cookie_secret))
fd = os.open(PRIVATE_PATH, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(fd, 'w') as stream:
    stream.write(text)
print('Created a private mode-0600 local config outside this package. Do not share or commit it.')
