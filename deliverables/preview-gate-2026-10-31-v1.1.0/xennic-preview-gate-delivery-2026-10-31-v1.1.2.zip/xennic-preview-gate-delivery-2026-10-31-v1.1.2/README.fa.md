# بستهٔ بازبینی Xennic Preview Gate

**نسخه:** `1.1.2` — ۲۰۲۶-۱۰-۳۱
**مبنای وبسایت:** `feerozmandi/xennic-website@418de2b5b3a272e79a824ccde5411dc25f1002cc`
**وضعیت:** فقط بازبینی ایستا؛ نه مجوز اجرا، استقرار یا تغییر زیرساخت.

## هشدار نسخه و اجرا

نسخهٔ `1.1.2` اصلاحات بازبینی ایستای `1.1.1` را در بر می‌گیرد. **نسخه‌های `1.1.1` و `1.1.0` برای اجرا `SUPERSEDED / DO NOT RUN` هستند.** خود 1.1.2 نیز تا بازبینی دستیار وبسایت، رفع blockerهای باز، بررسی digestها و تأیید صریح مالک نباید اجرا شود. در این نوبت هیچ stack، migration، seed، Caddy، Docker Compose یا آزمون برنامه‌ای راه‌اندازی نشده است.

`oauth2-proxy.example.toml` هنوز scope sentinel `UNAPPROVED_DO_NOT_RUN` دارد و sentinel مانع فنی startup نیست. `compose.oauth-lab.reference.yml` نیز به‌دلیل project/port/subnet قدیمی `DO NOT RUN` است. overlay آزمایش فقط gate مصنوعی دارد؛ OAuth/GitHub واقعی یا identity واقعی نیست. هیچ فایل این بسته را روی VPS، gate فعال، DNS یا رایانهٔ مالک اعمال نکنید.

مخزن عمومی است. اسکن package برای الگوهای شناخته‌شدهٔ Secret انجام می‌شود، اما کشف همهٔ Secretها را تضمین نمی‌کند. هیچ runtime secret، credential، cookie، private key یا دادهٔ کاربر واقعی عمداً داخل بسته نیست.

## اصلاحات نسخهٔ 1.1.2

- بررسی migration در Runbook دیگر boolean را به متن `true/false` تبدیل نمی‌کند؛ `psql -At` خروجی باینری `t/f` می‌دهد و شرط shell `t` با آن هماهنگ است.
- media upload از field موردانتظار Payload یعنی `_payload` برای metadata `alt` استفاده می‌کند.
- PNG تستی یک 1x1 RGBA معتبر است؛ طول، ساختار chunkها، CRC و zlib stream با بررسی ایستا کنترل شده‌اند.
- URL فایل رسانه با مسیر Payload `/api/media/file/...` سنجیده و همان مسیر با gate/بدون gate بررسی می‌شود.
- Caddy mock این مسیر واقعی فایل را نیز به‌عنوان API بدون gate رد می‌کند.
- اصلاحات v1.1.1 برای logout/Bearer، login تازه، cookie filtering و `/api/graphql` حفظ شده‌اند.

## فایل‌های راهنما

- [گزارش بازبینی](REVIEW-REPORT.fa.md) — اصلاحات، source review و blockerهای runtime باز.
- [Changelog](CHANGELOG.fa.md) — تغییرات v1.1.2 و فهرست فایل‌ها.
- [Runbook](RUNBOOK.fa.md) — ترتیب DB و مراحل آتی که تا بازبینی/مجوز قفل‌اند.
- [فهرست دستیار وبسایت](FILES-FOR-WEBSITE-ASSISTANT.fa.md) — درخواست بازبینی ایستا و سؤال‌های باز.
- [وضعیت اعتبارسنجی](VALIDATION.fa.md) — بررسی‌های ایستا و آزمون‌های اجرا‌نشده جداگانه.
- [نسخه‌ها و digestها](VERSIONS-DIGESTS.fa.md) — provenance و وضعیت imageها.
- `MANIFEST.json` و `SHA256SUMS` — checksum فایل‌های داخل بسته.

## ترتیب بازبینی

۱. فقط نسخهٔ `1.1.2` را از PR عمومی به دستیار وبسایت بدهید.
۲. تا پاسخ بازبین، حل blockerها و تأیید صریح مالک هیچ stack/Compose، migration، seed، OAuth، DNS یا آزمون برنامه‌ای اجرا نشود.
۳. پس از بازبینی، آزمون disposable جداگانه نیازمند digestهای تأییدشده و مجوز تازه است؛ این بسته مجوز VPS/gate/DNS نیست.

## یکپارچگی بسته

پس از استخراج ZIP، در ریشهٔ بسته:

```sh
sha256sum -c SHA256SUMS
python3 verify_bundle.py
```

Checksumها فقط یکپارچگی فایل‌ها را ثابت می‌کنند؛ provenance image، Compose merge، رفتار route یا موفقیت runtime را اثبات نمی‌کنند. TXT تحویل یک export کامل متنی است، نه ZIP با پسوند `.txt`.
