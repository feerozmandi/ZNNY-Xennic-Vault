#!/usr/bin/env python3
"""Validate/adapt review Caddyfiles; does not issue a certificate or bind a port."""
import json
import os
from pathlib import Path
import subprocess

base = Path(__file__).resolve().parent
binary = os.environ.get('CADDY_BIN', 'caddy')
env = dict(os.environ, GATE_ADDR='127.0.0.1:19001', APP_ADDR='127.0.0.1:19002', PUBLIC_AUTHORITY='preview.xennic.ir')
version = subprocess.run([binary, 'version'], capture_output=True, text=True, check=True).stdout.strip()
assert version.startswith('v2.11.7 '), 'Expected Caddy v2.11.7'

prod = subprocess.run([binary,'adapt','--config','Caddyfile','--adapter','caddyfile','--validate'],
                      cwd=base,env=env,capture_output=True,text=True,check=True)
data=json.loads(prod.stdout)
servers=data['apps']['http']['servers']
assert len(servers)==1
server=next(iter(servers.values()))
assert server['listen']==[':443']
assert server['automatic_https']['disable_redirects'] is True
issuer=data['apps']['tls']['automation']['policies'][0]['issuers'][0]
assert issuer['module']=='acme'
assert issuer['challenges']['http']['disabled'] is True
assert not issuer['challenges'].get('tls-alpn',{}).get('disabled',False)
print('PASS production review config adapts to HTTPS :443; HTTP redirect and HTTP-01 off; TLS-ALPN enabled')
print('LIMITATION: no ACME certificate issued or renewed; no public reachability test')

for config,subject in [('Caddyfile.lab','localhost'),('Caddyfile.payload.lab','preview.xennic.ir')]:
    result=subprocess.run([binary,'adapt','--config',config,'--adapter','caddyfile','--validate'],
                         cwd=base,env=env,capture_output=True,text=True,check=True)
    adapted=json.loads(result.stdout)
    local_servers=adapted['apps']['http']['servers']
    assert len(local_servers)==1 and next(iter(local_servers.values()))['listen']==[':443']
    policies=adapted['apps']['tls']['automation']['policies']
    assert any(subject in p.get('subjects',[]) and any(i.get('module')=='internal' for i in p.get('issuers',[])) for p in policies)
    print(f'PASS {config} adapts to internal-only lab TLS for {subject}')
print('LIMITATION: no local browser/CA verification; Payload overlay is not started by this checker')
