// Optional DevTools check against the isolated Caddy + REAL-Payload overlay only.
// It uses the synthetic gate stub, not OAuth/GitHub. Do not run on public DNS,
// production or a VPS. It prints booleans only, never tokens/cookies/passwords.
(async () => {
  if (location.origin !== 'https://preview.xennic.ir') throw new Error('Unexpected origin; stopped')
  if (!confirm('Continue only if this browser maps preview.xennic.ir to local loopback and the isolated synthetic-gate stack?')) throw new Error('Stopped')
  const form = document.createElement('form')
  const email = document.createElement('input'); email.type='email'; email.autocomplete='username'; email.required=true
  const password = document.createElement('input'); password.type='password'; password.autocomplete='current-password'; password.required=true
  for (const [text,input] of [['Synthetic Staff email',email],['Synthetic Staff password',password]]) {
    const label=document.createElement('label'); label.textContent=text+' '; label.append(input)
    form.append(label,document.createElement('br'))
  }
  const button=document.createElement('button'); button.type='submit'; button.textContent='Run isolated test'; form.append(button)
  Object.assign(form.style,{position:'fixed',zIndex:'2147483647',inset:'20% 20%',padding:'2rem',background:'white',color:'black'})
  document.body.append(form)
  const credentials=await new Promise(resolve=>form.addEventListener('submit',e=>{
    e.preventDefault(); const v={email:email.value,password:password.value}; email.value='';password.value='';form.remove();resolve(v)
  },{once:true}))
  const results={}; let token=''
  try {
    // Public synthetic marker accepted only by gate_stub.py; never a real session.
    document.cookie='__Host-preview_gate=synthetic-owner; Path=/; Secure; SameSite=Lax'
    const first=await fetch('/api/staff/first-register',{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:'Synthetic Preview Test',...credentials})})
    results.firstStaff=first.status===200
    let login
    if(results.firstStaff) login=await fetch('/api/staff/login',{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json'},body:JSON.stringify(credentials)})
    credentials.password=''
    const body=login?.ok?await login.json():{}
    token=typeof body.token==='string'?body.token:''
    results.login=Boolean(login?.ok&&token)
    if(results.login){
      const cookieMe=await fetch('/api/staff/me',{credentials:'same-origin',cache:'no-store'})
      results.payloadCookie=Boolean(cookieMe.ok&&(await cookieMe.json()).user)
      const logout=await fetch('/api/staff/logout',{method:'POST',credentials:'same-origin',cache:'no-store'})
      results.payloadLogout=logout.ok
      const bearerMe=await fetch('/api/staff/me',{credentials:'same-origin',cache:'no-store',headers:{Authorization:`Bearer ${token}`}})
      results.payloadBearerWithoutPayloadCookie=Boolean(bearerMe.ok&&(await bearerMe.json()).user)
    }
  } catch { results.requestCompleted=false }
  finally {
    credentials.email='';credentials.password='';token=''
    document.cookie='__Host-preview_gate=; Max-Age=0; Path=/; Secure; SameSite=Lax'
  }
  console.log('Synthetic Payload checks (booleans only):',results)
})()
