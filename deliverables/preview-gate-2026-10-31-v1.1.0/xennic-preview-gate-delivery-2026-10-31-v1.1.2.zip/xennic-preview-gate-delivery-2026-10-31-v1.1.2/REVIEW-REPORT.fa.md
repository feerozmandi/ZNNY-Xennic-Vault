# گزارش بازبینی اصلاحی — Xennic Preview Gate `1.1.2`

**مبنای وبسایت:** `feerozmandi/xennic-website@418de2b5b3a272e79a824ccde5411dc25f1002cc`
**دامنه:** تحویل عمومی برای بازبینی ایستا؛ بدون تغییر gate فعال، VPS، DNS یا سرویس مالک.
**وضعیت:** فقط بازبینی. نسخه‌های `1.1.1` و `1.1.0` `SUPERSEDED / DO NOT RUN` هستند. 1.1.2 نیز هنوز مجوز اجرا نیست.

## خلاصهٔ تصمیم

نسخهٔ 1.1.2 دو نقص قطعی گزارش‌شده در بازبینی ایستای v1.1.1 را اصلاح کرده است: خروجی boolean query migration اکنون با شرط `t` هم‌خوان است؛ media multipart/path/PNG در integration test اصلاح شده است. این تغییرها نه query را اجرا می‌کنند نه Payload endpoint را تأیید. **پذیرش برای آزمون ایزوله هنوز احراز نشده است**؛ digestهای image و Compose/direct-port blockers باقی‌اند.

هیچ Caddy/Compose stack، Payload/Postgres، migration، seed، OAuth/GitHub، browser، VPS، DNS یا gate فعال اجرا/تغییر نشده است. ابتدا فقط این نسخه را به دستیار وبسایت برای بازبینی مجدد بدهید؛ تا رفع blockerها و مجوز جداگانهٔ مالک stack اجرا نشود.

## اصلاحات دقیق 1.1.2

### Migration query

Runbook اکنون `SELECT (<boolean expression>);` را بدون `::text` اجرا می‌کند. در `psql -At`, ستون boolean به شکل `t`/`f` نمایش داده می‌شود؛ در نتیجه `test "$MIGRATION_OK" = t` با نتیجهٔ true هم‌خوان است. این سازگاری بر اساس قرارداد psql/متن query بازبینی شده، نه اجرای query یا DB. Query همچنان فقط ledger/baseline، وجود `shared.customers` و نبود batch `-1` را کنترل می‌کند؛ schema کامل یا restore را ثابت نمی‌کند.

### Payload media

- metadata در multipart field `_payload` به‌صورت JSON شامل `alt` است؛ فایل در field `file` ارسال می‌شود.
- PNG مصنوعی 1x1 RGBA جایگزین شد. fixture به‌صورت ایستا دارای PNG signature، IHDR/IDAT/IEND، CRC صحیح و zlib stream معتبر است؛ این جایگزین تست upload واقعی نیست.
- URL fallback و assertion اکنون `/api/media/file/{filename}` را بررسی می‌کنند و فقط origin `https://preview.xennic.ir` را می‌پذیرند.
- Caddy mock مسیر `/api/media/file/synthetic.png` را برای درخواست بدون gate یک API route می‌داند و انتظار 401 دارد.
- Integration test همچنان upload با gate+Payload Staff، دریافت metadata/bytes و denial بدون gate را هدف می‌گیرد؛ اجرا نشده است.

## رفتار Payload `3.91.0` — source review، نه endpoint test

در tarball دقیق Payload که در baseline pin شده است، default `useSessions: true` است؛ logout session با `req.user._sid` را حذف می‌کند؛ JWT strategy وجود همان `sid` را بررسی می‌کند. `/api/staff/me` در حالت بدون user HTTP 200 با `user:null` می‌دهد و logout handler cookie را expire می‌کند. این شواهد source-level هستند. Test code برای Bearer لغوشده `200/user:null` را انتظار دارد و قبل از آزمون auth بعدی login تازه می‌گیرد؛ سرور/DB اجرا نشده است.

## موارد تستی و ادعاهای مجاز

- `test_payload_caddy.mjs`: برنامهٔ آزمون Payload/Caddy واقعی با DB/media disposable؛ writeها فقط Staff مصنوعی و PNG مصنوعی‌اند. کد شامل `/api/graphql`, media upload/metadata/file bytes و gate success/denial است، اما خود آزمون اجرا نشده است.
- `test_caddy_mock.py`: synthetic gate/upstream؛ test code اکنون gate success، upstream reach و حذف gate Cookie را assert می‌کند، از جمله مسیر media file API. Caddy binary اجرا نشده.
- `test_payload_extraction.mjs`: test parser تاریخی برای Payload `3.91.0`; تکرار آن در بستهٔ 1.1.2 هنوز انجام نشده.

وجود این assertions یا اصلاح syntax مساوی PASS برنامه نیست. وضعیت دقیق در `VALIDATION.fa.md` است.

## Blockerهای باز

| مورد | وضعیت | دلیل بازبودن |
|---|---|---|
| Compose مؤثر | NOT VERIFIED | `config`/merge اجرا نشده؛ معنی عملی `!reset []`, ports, health و volume اثبات نشده است. |
| app direct-port bypass | NOT VERIFIED | overlay در متن publish app را reset می‌کند؛ runtime/IPv4/IPv6/host-path آزمایش نشده. |
| egress gate→GitHub | NOT TESTED | overlay gate stub + network `internal: true` دارد؛ OAuth egress واقعی وجود ندارد. |
| image digest/provenance | NOT VERIFIED | Caddy/Python digestهای نوشته‌شده resolve نشده‌اند؛ Node/Postgres tag-only هستند. |
| media endpoint contract | STATIC REVIEW PENDING | `_payload`, `/api/media/file/...` اکنون در test code هستند؛ Payload server اجرا نشده، پس response/form contract runtime نامعلوم است. |
| migration DB check | NOT RUN | cast رفع شده؛ خروجی واقعی psql/DB بررسی نشده است. |
| OAuth scope/account دوم, TLS/DNS, backup/restore | OPEN/OUT OF SCOPE | به بازبینی و آزمون مجاز جدا نیاز دارند؛ این بسته چیزی را اثبات نمی‌کند. |

## عدم تغییر و محدودیت

هیچ stack، registry image pull، migration، seed، OAuth/GitHub، VPS، DNS یا gate فعال تغییر نکرد. هیچ ادعای «ایمن برای اجرا»، «Compose بدون bypass» یا «media runtime موفق» نداریم. نسخهٔ 1.1.2 فقط پس از بازبینی دستیار وبسایت، digest verification و تأیید مالک می‌تواند وارد برنامهٔ آزمون جداگانه شود.
